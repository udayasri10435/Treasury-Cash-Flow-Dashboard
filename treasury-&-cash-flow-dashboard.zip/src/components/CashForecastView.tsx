import React, { useState, useMemo } from 'react';
import { Currency, ForecastScenario, UserPersona } from '../types/treasury';
import { generateForecastData } from '../utils/forecastEngine';
import { formatCurrency } from '../utils/formatters';
import {
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  Layers,
  ArrowDownLeft,
  ArrowUpRight,
  ShieldAlert,
} from 'lucide-react';

interface Props {
  initialCashUSD: number;
  baseCurrency: Currency;
  activeUser: UserPersona;
}

export const CashForecastView: React.FC<Props> = ({
  initialCashUSD,
  baseCurrency,
  activeUser,
}) => {
  const [horizonDays, setHorizonDays] = useState<30 | 60 | 90>(90);
  const [scenario, setScenario] = useState<ForecastScenario>('BASE_CASE');
  const [hoveredDayIndex, setHoveredDayIndex] = useState<number | null>(null);

  // Compute forecast dataset
  const forecast = useMemo(() => {
    return generateForecastData(initialCashUSD, horizonDays, scenario);
  }, [initialCashUSD, horizonDays, scenario]);

  const activeHoveredDay = hoveredDayIndex !== null ? forecast.days[hoveredDayIndex] : null;

  // SVG Chart Dimensions
  const chartWidth = 900;
  const chartHeight = 240;
  const paddingX = 40;
  const paddingY = 30;

  // Compute scale
  const allClosingCash = forecast.days.map((d) => d.closingCash);
  const maxCash = Math.max(...allClosingCash, initialCashUSD, 180000000) * 1.08;
  const minCash = Math.min(...allClosingCash, forecast.minBufferUSD, 0) * 0.9;
  const range = maxCash - minCash || 1;

  const getX = (index: number) => {
    return paddingX + (index / (forecast.days.length - 1)) * (chartWidth - paddingX * 2);
  };

  const getY = (val: number) => {
    return chartHeight - paddingY - ((val - minCash) / range) * (chartHeight - paddingY * 2);
  };

  // Build SVG Path
  const points = forecast.days.map((d, i) => `${getX(i)},${getY(d.closingCash)}`).join(' ');
  const areaPath = `${getX(0)},${getY(minCash)} ` + points + ` ${getX(forecast.days.length - 1)},${getY(minCash)}`;
  const bufferY = getY(forecast.minBufferUSD);

  const scenarioDescriptions: Record<ForecastScenario, string> = {
    BASE_CASE: 'Standard corporate operating plan with on-time collections & scheduled CapEx',
    CONSERVATIVE_AR_DELAY: 'Assumes enterprise clients delay receivable payments by +15 days',
    CAPEX_EXPANSION: 'Front-loads global server cluster and infrastructure expansion investments',
    MACRO_STRESS_TEST: 'Macroeconomic downturn: 30% contraction in new bookings & 12% vendor cost inflation',
  };

  return (
    <div className="space-y-6">
      {/* Control Banner */}
      <div className="border border-slate-800 bg-slate-900/60 rounded-xl p-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-slate-800/80">
          <div>
            <div className="text-xs text-slate-400 font-medium tracking-wide">
              Predictive Cash Flow Modeling &amp; Liquidity Horizon
            </div>
            <div className="flex items-center gap-3 mt-1">
              <span className="text-3xl font-bold font-mono tracking-tight text-slate-100 tabular-nums">
                {formatCurrency(forecast.projected90dUSD, baseCurrency)}
              </span>
              <span
                className={`text-xs font-mono font-medium px-2 py-0.5 rounded ${
                  forecast.netVarianceUSD >= 0
                    ? 'text-emerald-400 bg-emerald-950/60 border border-emerald-900/40'
                    : 'text-rose-400 bg-rose-950/60 border border-rose-900/40'
                }`}
              >
                {forecast.netVarianceUSD >= 0 ? '+' : ''}
                {formatCurrency(forecast.netVarianceUSD, baseCurrency, true)} Net Delta
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-2 max-w-xl">
              {scenarioDescriptions[scenario]}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            {/* Horizon Picker */}
            <div className="flex items-center bg-slate-950 border border-slate-800 rounded-lg p-0.5 text-xs">
              {[30, 60, 90].map((h) => (
                <button
                  key={h}
                  onClick={() => setHorizonDays(h as any)}
                  className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                    horizonDays === h
                      ? 'bg-slate-800 text-cyan-300 shadow-xs'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {h} Days
                </button>
              ))}
            </div>

            {/* Scenario Dropdown */}
            <div className="space-y-1">
              <select
                value={scenario}
                onChange={(e) => setScenario(e.target.value as ForecastScenario)}
                className="bg-slate-950 border border-slate-800 text-slate-200 text-xs rounded-lg px-3 py-1.5 focus:outline-hidden focus:border-cyan-500 cursor-pointer font-medium"
              >
                <option value="BASE_CASE">Scenario: Base Case Operating Plan</option>
                <option value="CONSERVATIVE_AR_DELAY">Stress: Conservative AR Delay (+15d)</option>
                <option value="CAPEX_EXPANSION">Stress: CapEx Infrastructure Surge</option>
                <option value="MACRO_STRESS_TEST">Severe: Macroeconomic Downturn (-30%)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Executive KPI Bar */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 pt-5">
          <div className="p-3 bg-slate-950/70 border border-slate-800/80 rounded-lg">
            <div className="text-[11px] text-slate-400 font-medium">Days of Cash on Hand (DCOH)</div>
            <div className="text-lg font-mono font-semibold text-slate-100 mt-1 tabular-nums">
              {forecast.dcoh} Days
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">Operating coverage ratio</div>
          </div>

          <div className="p-3 bg-slate-950/70 border border-slate-800/80 rounded-lg">
            <div className="text-[11px] text-slate-400 font-medium">Liquidity Runway</div>
            <div className="text-lg font-mono font-semibold text-cyan-400 mt-1 tabular-nums">
              {forecast.runwayMonths} Months
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">At current burn projection</div>
          </div>

          <div className="p-3 bg-slate-950/70 border border-slate-800/80 rounded-lg">
            <div className="text-[11px] text-slate-400 font-medium">Policy Buffer ($25M Floor)</div>
            <div className="text-lg font-mono font-semibold mt-1 flex items-center gap-1.5 tabular-nums">
              {forecast.bufferBreachDay ? (
                <span className="text-rose-400 flex items-center gap-1">
                  <AlertTriangle className="w-4 h-4" />
                  Breach Day {forecast.bufferBreachDay}
                </span>
              ) : (
                <span className="text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" />
                  Sufficient ($25M Safe)
                </span>
              )}
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">Board liquidity policy</div>
          </div>

          <div className="p-3 bg-slate-950/70 border border-slate-800/80 rounded-lg">
            <div className="text-[11px] text-slate-400 font-medium">Total Inflows vs Outflows</div>
            <div className="text-sm font-mono font-semibold text-slate-200 mt-1 tabular-nums flex items-center justify-between">
              <span className="text-emerald-400">+{formatCurrency(forecast.totalInflow90d, baseCurrency, true)}</span>
              <span className="text-rose-400">-{formatCurrency(forecast.totalOutflow90d, baseCurrency, true)}</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">Aggregate {horizonDays}-day horizon</div>
          </div>
        </div>
      </div>

      {/* Interactive SVG Cash Runway Chart */}
      <div className="border border-slate-800 bg-slate-900/60 rounded-xl p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-800">
          <div>
            <h2 className="text-xs font-semibold text-slate-200 tracking-wide">
              Cash Trajectory &amp; Daily Net Inflow/Outflow Waterfall
            </h2>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Hover over timeline to inspect granular daily treasury movements
            </p>
          </div>
          <div className="flex items-center gap-4 text-[11px] text-slate-400 font-mono">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-0.5 bg-cyan-400 inline-block" />
              <span>Projected Closing Cash</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-0.5 bg-rose-500 inline-block border-b border-dashed" />
              <span>$25M Policy Buffer</span>
            </div>
          </div>
        </div>

        {/* SVG Viewport */}
        <div className="pt-4 relative">
          <svg
            viewBox={`0 0 ${chartWidth} ${chartHeight}`}
            className="w-full h-64 overflow-visible select-none"
            onMouseLeave={() => setHoveredDayIndex(null)}
          >
            <defs>
              <linearGradient id="cashGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.28" />
                <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.0" />
              </linearGradient>
            </defs>

            {/* Horizontal Grid Lines */}
            {[0.25, 0.5, 0.75].map((pct) => {
              const yPos = paddingY + pct * (chartHeight - paddingY * 2);
              return (
                <line
                  key={pct}
                  x1={paddingX}
                  y1={yPos}
                  x2={chartWidth - paddingX}
                  y2={yPos}
                  stroke="#334155"
                  strokeDasharray="3 3"
                  strokeOpacity="0.4"
                />
              );
            })}

            {/* Minimum Cash Buffer Line ($25M) */}
            <line
              x1={paddingX}
              y1={bufferY}
              x2={chartWidth - paddingX}
              y2={bufferY}
              stroke="#f43f5e"
              strokeDasharray="4 4"
              strokeWidth="1.5"
            />
            <text
              x={chartWidth - paddingX - 100}
              y={bufferY - 6}
              fill="#f43f5e"
              fontSize="10"
              fontFamily="monospace"
            >
              $25M Policy Floor
            </text>

            {/* Cash Area fill */}
            <polygon points={areaPath} fill="url(#cashGradient)" />

            {/* Cash Line */}
            <polyline
              points={points}
              fill="none"
              stroke="#06b6d4"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />

            {/* Daily Inflow/Outflow vertical impulse bars */}
            {forecast.days.map((d, i) => {
              const x = getX(i);
              const isSelected = hoveredDayIndex === i;
              const netHeight = Math.min(Math.abs(d.netCashFlow) / 120000, 36);
              const isPositive = d.netCashFlow >= 0;

              return (
                <g key={i}>
                  {/* Subtle bar near bottom */}
                  <rect
                    x={x - 1.5}
                    y={isPositive ? chartHeight - paddingY - netHeight : chartHeight - paddingY}
                    width={3}
                    height={netHeight}
                    fill={isPositive ? '#10b981' : '#f43f5e'}
                    opacity={isSelected ? 0.9 : 0.4}
                  />

                  {/* Invisible broad hitbox for mouse hover */}
                  <rect
                    x={x - (chartWidth / forecast.days.length) / 2}
                    y={0}
                    width={chartWidth / forecast.days.length}
                    height={chartHeight}
                    fill="transparent"
                    className="cursor-crosshair"
                    onMouseEnter={() => setHoveredDayIndex(i)}
                  />

                  {/* Active highlight dot */}
                  {isSelected && (
                    <>
                      <line
                        x1={x}
                        y1={paddingY}
                        x2={x}
                        y2={chartHeight - paddingY}
                        stroke="#38bdf8"
                        strokeDasharray="2 2"
                      />
                      <circle
                        cx={x}
                        cy={getY(d.closingCash)}
                        r="5"
                        fill="#38bdf8"
                        stroke="#0f172a"
                        strokeWidth="2"
                      />
                    </>
                  )}
                </g>
              );
            })}
          </svg>

          {/* Scrub Tooltip Overlay */}
          {activeHoveredDay && (
            <div className="mt-3 p-3 bg-slate-950 border border-slate-700/80 rounded-lg flex flex-wrap items-center justify-between gap-4 text-xs">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-cyan-400" />
                <span className="font-semibold text-slate-200">
                  Day {activeHoveredDay.dayIndex} &middot; {activeHoveredDay.dateStr}
                </span>
              </div>

              <div className="flex items-center gap-6 font-mono text-[11px]">
                <div>
                  <span className="text-slate-400">Inflows: </span>
                  <span className="text-emerald-400">+{formatCurrency(activeHoveredDay.totalInflow, baseCurrency)}</span>
                </div>
                <div>
                  <span className="text-slate-400">Outflows: </span>
                  <span className="text-rose-400">-{formatCurrency(activeHoveredDay.totalOutflow, baseCurrency)}</span>
                </div>
                <div>
                  <span className="text-slate-400">Net: </span>
                  <span className={activeHoveredDay.netCashFlow >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                    {activeHoveredDay.netCashFlow >= 0 ? '+' : ''}
                    {formatCurrency(activeHoveredDay.netCashFlow, baseCurrency)}
                  </span>
                </div>
                <div className="font-bold text-slate-100">
                  <span className="text-slate-400 font-normal">Closing Cash: </span>
                  <span className="text-cyan-300">{formatCurrency(activeHoveredDay.closingCash, baseCurrency)}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Inflow vs Outflow Driver Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Inflows breakdown */}
        <div className="border border-slate-800 bg-slate-900/60 rounded-xl p-5 space-y-3">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <ArrowDownLeft className="w-4 h-4 text-emerald-400" />
              <h3 className="text-xs font-semibold text-slate-200">Forecasted Inflow Drivers</h3>
            </div>
            <span className="text-xs font-mono text-emerald-400 font-medium">
              +{formatCurrency(forecast.totalInflow90d, baseCurrency, true)}
            </span>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-300">Customer AR Collections</span>
              <span className="font-mono text-slate-200 font-medium">68% of Inflows &middot; Daily Billing</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-300">Enterprise SaaS Subscriptions</span>
              <span className="font-mono text-slate-200 font-medium">Month-End Recurring ARR</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-300">MMF &amp; Treasury Yield Accruals</span>
              <span className="font-mono text-slate-200 font-medium">~5.10% APY Blended Return</span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="text-slate-300">Tax Credits &amp; Intercompany Inflows</span>
              <span className="font-mono text-slate-200 font-medium">Bi-weekly Scheduled</span>
            </div>
          </div>
        </div>

        {/* Outflows breakdown */}
        <div className="border border-slate-800 bg-slate-900/60 rounded-xl p-5 space-y-3">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <ArrowUpRight className="w-4 h-4 text-rose-400" />
              <h3 className="text-xs font-semibold text-slate-200">Forecasted Outflow Drivers</h3>
            </div>
            <span className="text-xs font-mono text-rose-400 font-medium">
              -{formatCurrency(forecast.totalOutflow90d, baseCurrency, true)}
            </span>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-300">Global Bi-Weekly Payroll Runs</span>
              <span className="font-mono text-slate-200 font-medium">~$4.85M per cycle (Tier 1 cash)</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-300">Vendor AP &amp; Cloud Infrastructure</span>
              <span className="font-mono text-slate-200 font-medium">Daily batch settlements</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-300">CapEx Hardware &amp; Facilities</span>
              <span className="font-mono text-slate-200 font-medium">Quarterly scheduled disbursements</span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="text-slate-300">Corporate Tax &amp; Debt Service</span>
              <span className="font-mono text-slate-200 font-medium">Quarter-end scheduled filings</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
