import React, { useState } from 'react';
import {
  Currency,
  FXExposureHolding,
  FXHedgeContract,
  FXRate,
  UserPersona,
} from '../types/treasury';
import { formatCurrency } from '../utils/formatters';
import {
  TrendingUp,
  TrendingDown,
  ShieldCheck,
  Plus,
  RefreshCw,
  SlidersHorizontal,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';

interface Props {
  fxExposures: FXExposureHolding[];
  fxHedges: FXHedgeContract[];
  fxRates: FXRate[];
  baseCurrency: Currency;
  activeUser: UserPersona;
  onOpenHedgeModal: () => void;
  onSimulateRateShock: () => void;
}

export const FXExposureView: React.FC<Props> = ({
  fxExposures,
  fxHedges,
  fxRates,
  baseCurrency,
  activeUser,
  onOpenHedgeModal,
  onSimulateRateShock,
}) => {
  const [selectedCurrency, setSelectedCurrency] = useState<Currency | 'ALL'>('ALL');

  // Compute portfolio metrics
  const totalNetExposureUSD = fxExposures.reduce((s, h) => s + Math.abs(h.netPositionUSD), 0);
  const totalHedgedUSD = fxExposures.reduce((s, h) => s + h.hedgedAmountUSD, 0);
  const totalUnhedgedUSD = fxExposures.reduce((s, h) => s + Math.abs(h.unhedgedExposureUSD), 0);
  const totalMTMUSD = fxHedges.reduce((s, h) => s + h.markToMarketUSD, 0);

  // 1-Day 95% Value at Risk approximation (assuming 1.65 std dev of daily volatility ~0.65%)
  const portfolioVaR95USD = Math.round(totalUnhedgedUSD * 0.0065 * 1.645);

  const filteredHedges = fxHedges.filter((h) => {
    if (selectedCurrency === 'ALL') return true;
    return h.nativeCurrency === selectedCurrency || h.counterCurrency === selectedCurrency;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="border border-slate-800 bg-slate-900/60 rounded-xl p-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-slate-800/80">
          <div>
            <div className="text-xs text-slate-400 font-medium tracking-wide">
              Foreign Exchange Net Open Position (NOP) &amp; Hedging Cockpit
            </div>
            <div className="flex items-center gap-3 mt-1">
              <span className="text-3xl font-bold font-mono tracking-tight text-slate-100 tabular-nums">
                {formatCurrency(totalNetExposureUSD, 'USD')}
              </span>
              <span className="text-xs font-mono font-medium px-2 py-0.5 rounded bg-cyan-950/70 text-cyan-400 border border-cyan-800/50">
                {((totalHedgedUSD / totalNetExposureUSD) * 100).toFixed(1)}% Portfolio Hedged
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-400 mt-2">
              <span>95% 1-Day Value-at-Risk (VaR): {formatCurrency(portfolioVaR95USD, 'USD')}</span>
              <span aria-hidden="true">&middot;</span>
              <span className={totalMTMUSD >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                Unrealized MTM P&amp;L: {totalMTMUSD >= 0 ? '+' : ''}{formatCurrency(totalMTMUSD, 'USD')}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              onClick={onSimulateRateShock}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-750 border border-slate-700 text-xs font-medium text-slate-200 rounded-lg transition-colors cursor-pointer"
              title="Simulate currency market fluctuation"
            >
              <SlidersHorizontal className="w-3.5 h-3.5 text-amber-400" />
              <span>Simulate FX Rate Shock</span>
            </button>
            <button
              onClick={onOpenHedgeModal}
              disabled={!activeUser.permissions.canExecuteFXHedges && activeUser.role !== 'CHIEF_TREASURER'}
              className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 disabled:text-slate-600 text-white text-xs font-medium rounded-lg transition-colors cursor-pointer shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Execute FX Hedge</span>
            </button>
          </div>
        </div>

        {/* Live Interbank FX Spot & Forward Ticker */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 pt-5">
          {fxRates.map((rate) => {
            const isUp = rate.change24h >= 0;
            return (
              <div
                key={rate.pair}
                className="p-3 bg-slate-950/70 border border-slate-800/80 rounded-lg text-xs"
              >
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-200 font-mono text-[11px]">{rate.pair}</span>
                  <span
                    className={`font-mono text-[11px] flex items-center font-medium ${
                      isUp ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {isUp ? <TrendingUp className="w-3 h-3 mr-0.5" /> : <TrendingDown className="w-3 h-3 mr-0.5" />}
                    {isUp ? '+' : ''}
                    {rate.change24h.toFixed(2)}%
                  </span>
                </div>
                <div className="text-lg font-mono font-semibold text-slate-100 mt-1 tabular-nums">
                  {rate.rate.toFixed(4)}
                </div>
                <div className="text-[10px] text-slate-400 flex justify-between mt-1 pt-1 border-t border-slate-800/60 font-mono">
                  <span>30d: {rate.forward30d.toFixed(4)}</span>
                  <span>90d: {rate.forward90d.toFixed(4)}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Currency Net Position & Hedge Ratio Breakdown */}
      <div className="border border-slate-800 bg-slate-900/60 rounded-xl overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-800 flex items-center justify-between">
          <h2 className="text-xs font-semibold text-slate-200 tracking-wide">
            Currency Net Open Positions &amp; Target Hedge Ratios
          </h2>
          <span className="text-[11px] text-slate-400 font-mono">Board Mandated 80% Policy Target</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 text-[11px] font-medium">
                <th className="py-2.5 px-4">Currency</th>
                <th className="py-2.5 px-4 text-right">Gross Assets (USD)</th>
                <th className="py-2.5 px-4 text-right">Gross Liabilities (USD)</th>
                <th className="py-2.5 px-4 text-right">Net Open Position</th>
                <th className="py-2.5 px-4 text-right">Active Hedges</th>
                <th className="py-2.5 px-4 text-right">Unhedged At-Risk</th>
                <th className="py-2.5 px-4">Hedge Ratio (%)</th>
                <th className="py-2.5 px-4 text-right">Policy Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {fxExposures.map((item) => {
                const isCompliant = item.hedgeRatioPercent >= item.targetHedgeRatio;
                return (
                  <tr key={item.currency} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-slate-200">
                      {item.currency}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-200">
                      {formatCurrency(item.grossAssetsUSD, 'USD', true)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-400">
                      {formatCurrency(item.grossLiabilitiesUSD, 'USD', true)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums font-semibold text-slate-100">
                      {formatCurrency(item.netPositionUSD, 'USD', true)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-cyan-400">
                      {formatCurrency(item.hedgedAmountUSD, 'USD', true)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-amber-400">
                      {formatCurrency(item.unhedgedExposureUSD, 'USD', true)}
                    </td>
                    <td className="py-3 px-4">
                      <div className="w-32">
                        <div className="flex justify-between text-[10px] text-slate-400 font-mono mb-1">
                          <span>{item.hedgeRatioPercent.toFixed(1)}%</span>
                          <span>Target: {item.targetHedgeRatio.toFixed(0)}%</span>
                        </div>
                        <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${
                              isCompliant ? 'bg-emerald-500' : 'bg-amber-500'
                            }`}
                            style={{ width: `${Math.min(item.hedgeRatioPercent, 100)}%` }}
                          />
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-right">
                      {isCompliant ? (
                        <span className="text-[11px] text-emerald-400 flex items-center justify-end gap-1 font-mono">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          Compliant
                        </span>
                      ) : (
                        <span className="text-[11px] text-amber-400 flex items-center justify-end gap-1 font-mono">
                          <AlertCircle className="w-3.5 h-3.5" />
                          Under-Hedged
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Active Hedging Contracts Portfolio */}
      <div className="border border-slate-800 bg-slate-900/60 rounded-xl overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h2 className="text-xs font-semibold text-slate-200 tracking-wide">
              Active FX Derivative &amp; Forward Hedging Contracts
            </h2>
            <p className="text-[11px] text-slate-400 mt-0.5">
              ISDA Master Agreements &middot; Mark-to-market revaluations against live interbank mid rates
            </p>
          </div>
          <button
            onClick={onOpenHedgeModal}
            className="text-xs text-cyan-400 hover:text-cyan-300 font-medium cursor-pointer"
          >
            + New Forward
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 text-[11px] font-medium">
                <th className="py-2.5 px-4">Contract Ref</th>
                <th className="py-2.5 px-4">Instrument</th>
                <th className="py-2.5 px-4">Pair</th>
                <th className="py-2.5 px-4 text-right">Notional</th>
                <th className="py-2.5 px-4 text-right">Locked Rate</th>
                <th className="py-2.5 px-4 text-right">Current Rate</th>
                <th className="py-2.5 px-4 text-right">MTM P&amp;L (USD)</th>
                <th className="py-2.5 px-4">Settlement</th>
                <th className="py-2.5 px-4">Dealer Counterparty</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredHedges.map((hdg) => {
                const isGain = hdg.markToMarketUSD >= 0;
                return (
                  <tr key={hdg.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4 font-mono font-medium text-slate-200">
                      {hdg.contractRef}
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-mono text-[11px] text-slate-300 bg-slate-800 px-1.5 py-0.5 rounded">
                        {hdg.instrument.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono text-cyan-300">{hdg.pair}</td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-200 font-medium">
                      {formatCurrency(hdg.notionalNative, hdg.nativeCurrency)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-300">
                      {hdg.lockedRate.toFixed(4)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-400">
                      {hdg.currentRate.toFixed(4)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums font-semibold">
                      <span className={isGain ? 'text-emerald-400' : 'text-rose-400'}>
                        {isGain ? '+' : ''}
                        {formatCurrency(hdg.markToMarketUSD, 'USD')}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-300 text-[11px]">
                      {hdg.settlementDate}
                    </td>
                    <td className="py-3 px-4 text-slate-300 truncate max-w-[160px]">
                      {hdg.counterpartyBank}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
