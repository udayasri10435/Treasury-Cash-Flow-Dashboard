import React, { useState } from 'react';
import { BankAccount } from '../../types/treasury';
import { FileText, CheckCircle2, UploadCloud, X, ArrowRight, ShieldCheck } from 'lucide-react';
import { formatCurrency } from '../../utils/formatters';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  accounts: BankAccount[];
  onReconciliationComplete: (accountId: string, newBalance: number, memo: string) => void;
}

const SAMPLE_MT940 = `:20:TR20260928019482
:25:NL44BNPA0123456621
:28C:00084/001
:60F:C260927EUR28450000,00
:61:2609280928CR5000000,00NTRFNONREF//SEPA-INCOMING-REVENUE
:86:SEPA CREDIT TRANSFER / B2B ENTERPRISE SUBSCRIPTIONS BATCH 89
:61:2609281200DR1250000,00NTRFNONREF//VENDOR-AP-SETTLEMENT
:86:CLOUD INFRASTRUCTURE OPERATIONS WIRE
:62F:C260928EUR32200000,00
-}`;

export const SwiftParserModal: React.FC<Props> = ({
  isOpen,
  onClose,
  accounts,
  onReconciliationComplete,
}) => {
  const [statementText, setStatementText] = useState(SAMPLE_MT940);
  const [parsedData, setParsedData] = useState<{
    reference: string;
    accountIban: string;
    currency: string;
    closingBalance: number;
    transactionsCount: number;
  } | null>(null);

  if (!isOpen) return null;

  const handleParse = () => {
    // Parse SWIFT MT940 format
    const lines = statementText.split('\n');
    let reference = 'UNKNOWN';
    let accountIban = '';
    let closingBalance = 0;
    let currency = 'EUR';
    let txCount = 0;

    for (const line of lines) {
      if (line.startsWith(':20:')) {
        reference = line.substring(4).trim();
      } else if (line.startsWith(':25:')) {
        accountIban = line.substring(4).trim();
      } else if (line.startsWith(':61:')) {
        txCount++;
      } else if (line.startsWith(':62F:')) {
        // e.g. :62F:C260928EUR32200000,00
        const content = line.substring(5);
        currency = content.substring(7, 10);
        const amountPart = content.substring(10).replace(',', '.');
        closingBalance = parseFloat(amountPart) || 0;
      }
    }

    setParsedData({
      reference,
      accountIban,
      currency,
      closingBalance,
      transactionsCount: txCount,
    });
  };

  const handleApplyReconciliation = () => {
    if (!parsedData) return;
    const matchingAccount = accounts.find((a) => a.iban === parsedData.accountIban) || accounts[3];
    onReconciliationComplete(
      matchingAccount.id,
      parsedData.closingBalance,
      `SWIFT MT940 Reconciled: Ref ${parsedData.reference} (${parsedData.transactionsCount} txs applied)`
    );
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-cyan-400" />
            <div>
              <h2 className="text-sm font-semibold text-slate-100">
                SWIFT MT940 &amp; ISO 20022 CAMT.053 Ingestion
              </h2>
              <p className="text-[11px] text-slate-400">
                Host-to-host electronic bank statement parser &amp; automated ledger reconciler
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 p-1.5 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <div className="space-y-1.5">
            <div className="flex justify-between items-center text-xs">
              <label className="font-medium text-slate-300">Raw Bank Statement Payload (MT940 / CAMT)</label>
              <button
                type="button"
                onClick={() => setStatementText(SAMPLE_MT940)}
                className="text-cyan-400 hover:text-cyan-300 text-[11px] cursor-pointer"
              >
                Reset to Sample BNP Statement
              </button>
            </div>
            <textarea
              rows={8}
              value={statementText}
              onChange={(e) => setStatementText(e.target.value)}
              className="w-full p-3 bg-slate-950 border border-slate-800 rounded-lg text-xs font-mono text-slate-200 focus:outline-hidden focus:border-cyan-500"
            />
          </div>

          <div className="flex justify-between items-center">
            <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Conforms to SWIFT Alliance Release Standards &amp; ISO 20022 XML Schema</span>
            </div>
            <button
              type="button"
              onClick={handleParse}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg cursor-pointer flex items-center gap-1.5 border border-slate-700"
            >
              <UploadCloud className="w-3.5 h-3.5 text-cyan-400" />
              <span>Parse &amp; Validate Tags</span>
            </button>
          </div>

          {parsedData && (
            <div className="p-4 bg-slate-950 rounded-lg border border-cyan-900/40 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-cyan-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                  Validated SWIFT Statement Structure
                </span>
                <span className="text-[11px] text-slate-400 font-mono">Ref: {parsedData.reference}</span>
              </div>

              <div className="grid grid-cols-3 gap-3 text-xs">
                <div>
                  <div className="text-slate-400 text-[11px]">Target Account IBAN</div>
                  <div className="font-mono text-slate-200 mt-0.5">{parsedData.accountIban}</div>
                </div>
                <div>
                  <div className="text-slate-400 text-[11px]">Transactions Detected</div>
                  <div className="font-mono text-slate-200 mt-0.5">{parsedData.transactionsCount} entries</div>
                </div>
                <div>
                  <div className="text-slate-400 text-[11px]">Reconciled Balance (:62F:)</div>
                  <div className="font-mono text-emerald-400 font-medium mt-0.5">
                    {parsedData.currency} {formatCurrency(parsedData.closingBalance, parsedData.currency as any)}
                  </div>
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  onClick={handleApplyReconciliation}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium rounded-lg cursor-pointer flex items-center gap-1.5 transition-colors"
                >
                  <span>Reconcile Ledger &amp; Update Cash Pool</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
