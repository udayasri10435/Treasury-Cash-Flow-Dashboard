import React, { useState } from 'react';
import { LedgerBlock, UserPersona } from '../../types/treasury';
import { FileCheck2, Download, Copy, Check, X, ShieldAlert } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  chain: LedgerBlock[];
  activeUser: UserPersona;
  isValidChain: boolean;
}

export const AuditExportModal: React.FC<Props> = ({
  isOpen,
  onClose,
  chain,
  activeUser,
  isValidChain,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const exportPayload = {
    exportDate: new Date().toISOString(),
    certifyingOfficer: activeUser.name,
    officerRole: activeUser.roleTitle,
    sox404ComplianceStatus: isValidChain ? 'VERIFIED_CRYPTOGRAPHICALLY_SOUND' : 'INTEGRITY_BREACH_DETECTED',
    blockchainHeadHash: chain[chain.length - 1]?.hash || '',
    totalBlocksAudited: chain.length,
    ledgerChain: chain,
  };

  const jsonString = JSON.stringify(exportPayload, null, 2);

  const handleCopy = () => {
    navigator.clipboard.writeText(jsonString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `treasury_sox404_ledger_audit_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-2">
            <FileCheck2 className="w-5 h-5 text-cyan-400" />
            <div>
              <h2 className="text-sm font-semibold text-slate-100">
                SOX 404 Treasury Compliance &amp; Immutable Ledger Dossier
              </h2>
              <p className="text-[11px] text-slate-400">
                Cryptographically certified audit package with SHA-256 block chain proofs
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 p-1.5 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <div className="flex items-center justify-between p-3 rounded-lg border bg-slate-950 text-xs">
            <div>
              <div className="text-slate-400 text-[11px]">Certifying Auditor / Officer</div>
              <div className="text-slate-200 font-medium mt-0.5">{activeUser.name} &middot; {activeUser.roleTitle}</div>
            </div>
            <div className="text-right">
              <div className="text-slate-400 text-[11px]">Cryptographic State</div>
              <div className={`font-mono font-medium mt-0.5 ${isValidChain ? 'text-emerald-400' : 'text-rose-400 flex items-center gap-1'}`}>
                {isValidChain ? 'VALIDATED (100% SOUND)' : <><ShieldAlert className="w-3.5 h-3.5" /> BREACH DETECTED</>}
              </div>
            </div>
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between items-center text-xs">
              <label className="font-medium text-slate-300">Certified Audit Payload (JSON)</label>
              <button
                type="button"
                onClick={handleCopy}
                className="flex items-center gap-1 text-[11px] text-cyan-400 hover:text-cyan-300 cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied to Clipboard' : 'Copy JSON'}</span>
              </button>
            </div>
            <pre className="p-3 bg-slate-950 border border-slate-800 rounded-lg text-[11px] font-mono text-slate-300 max-h-64 overflow-y-auto leading-relaxed">
              {jsonString}
            </pre>
          </div>

          <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
            >
              Close
            </button>
            <button
              type="button"
              onClick={handleDownload}
              className="flex items-center gap-2 px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-medium rounded-lg transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Signed Audit JSON</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
