import React, { useState } from 'react';
import { Currency, FXRate, UserPersona } from '../../types/treasury';
import { formatCurrency } from '../../utils/formatters';
import { ShieldCheck, TrendingUp, X, CheckCircle2 } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  fxRates: FXRate[];
  activeUser: UserPersona;
  onConfirmHedge: (hedgeData: {
    pair: string;
    instrument: 'FORWARD' | 'SWAP' | 'COLLAR_OPTION';
    notionalNative: number;
    nativeCurrency: Currency;
    counterCurrency: Currency;
    lockedRate: number;
    settlementDate: string;
    counterpartyBank: string;
  }) => void;
}

export const ExecuteHedgeModal: React.FC<Props> = ({
  isOpen,
  onClose,
  fxRates,
  activeUser,
  onConfirmHedge,
}) => {
  const [selectedPair, setSelectedPair] = useState<string>('EUR/USD');
  const [instrument, setInstrument] = useState<'FORWARD' | 'SWAP' | 'COLLAR_OPTION'>('FORWARD');
  const [notionalStr, setNotionalStr] = useState<string>('5000000');
  const [settlementDate, setSettlementDate] = useState<string>('2026-11-30');
  const [counterpartyBank, setCounterpartyBank] = useState<string>('JPMorgan Chase Bank, London');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  if (!isOpen) return null;

  const currentRateObj = fxRates.find((r) => r.pair === selectedPair) || fxRates[0];
  const lockedRate = currentRateObj?.rate || 1.0845;
  const notional = parseFloat(notionalStr) || 0;
  const nativeCurrency = currentRateObj.base;
  const counterCurrency = currentRateObj.quote;

  const isCFO = activeUser.role === 'CHIEF_TREASURER';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (notional <= 0) return;

    setIsSubmitting(true);
    setTimeout(() => {
      onConfirmHedge({
        pair: selectedPair,
        instrument,
        notionalNative: notional,
        nativeCurrency,
        counterCurrency,
        lockedRate,
        settlementDate,
        counterpartyBank,
      });
      setIsSubmitting(false);
      onClose();
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90">
          <div>
            <h2 className="text-base font-semibold text-slate-100">Execute FX Hedging Contract</h2>
            <p className="text-xs text-slate-400 mt-0.5">Hedge foreign exchange exposure and lock forward rates</p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 p-1.5 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Pair & Instrument */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-300">Currency Pair</label>
              <select
                value={selectedPair}
                onChange={(e) => setSelectedPair(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-hidden focus:border-cyan-500"
              >
                {fxRates.map((r) => (
                  <option key={r.pair} value={r.pair}>
                    {r.pair} (Spot: {r.rate.toFixed(4)})
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-300">Hedging Instrument</label>
              <select
                value={instrument}
                onChange={(e) => setInstrument(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-hidden focus:border-cyan-500"
              >
                <option value="FORWARD">FX Outright Forward</option>
                <option value="SWAP">FX Liquidity Swap</option>
                <option value="COLLAR_OPTION">Zero-Cost FX Collar Option</option>
              </select>
            </div>
          </div>

          {/* Notional Amount & Rate Display */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-300">Notional ({nativeCurrency})</label>
              <input
                type="number"
                min="10000"
                step="10000"
                value={notionalStr}
                onChange={(e) => setNotionalStr(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs font-mono tabular-nums text-slate-100 focus:outline-hidden focus:border-cyan-500"
              />
              <p className="text-[11px] text-slate-400">
                Eq. Counter: {formatCurrency(notional * lockedRate, counterCurrency)}
              </p>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-300">Locked Forward Rate</label>
              <div className="w-full px-3 py-2 bg-slate-950/70 border border-slate-800 rounded-lg text-xs font-mono tabular-nums text-cyan-400 flex items-center justify-between">
                <span>{lockedRate.toFixed(4)}</span>
                <span className="text-[11px] text-slate-400">30d Fwd: {currentRateObj.forward30d.toFixed(4)}</span>
              </div>
              <p className="text-[11px] text-slate-400">Rate fixed against spot interbank market</p>
            </div>
          </div>

          {/* Settlement Date & Counterparty */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-300">Value / Settlement Date</label>
              <input
                type="date"
                value={settlementDate}
                onChange={(e) => setSettlementDate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-hidden focus:border-cyan-500"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-300">Counterparty Dealer Bank</label>
              <select
                value={counterpartyBank}
                onChange={(e) => setCounterpartyBank(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-hidden focus:border-cyan-500"
              >
                <option value="JPMorgan Chase Bank, London">JPMorgan Chase Bank, London</option>
                <option value="Citigroup Global Markets">Citigroup Global Markets</option>
                <option value="Barclays Corporate FX">Barclays Corporate FX</option>
                <option value="BNP Paribas Financial Markets">BNP Paribas Financial Markets</option>
                <option value="HSBC Global Banking Markets">HSBC Global Banking Markets</option>
              </select>
            </div>
          </div>

          {/* RBAC signoff box */}
          <div className="p-3 bg-slate-950/80 rounded-lg border border-slate-800 text-xs space-y-1">
            <div className="flex items-center gap-2 text-slate-300">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span className="font-medium">ISDA Master Agreement &amp; Policy Authorization</span>
            </div>
            <p className="text-slate-400 text-[11px]">
              Executed under corporate FX Risk Policy. Will be signed by active persona{' '}
              <strong className="text-slate-200">{activeUser.name}</strong> ({activeUser.roleTitle}).
            </p>
            {!isCFO && (
              <p className="text-amber-400 text-[11px]">
                Requires secondary co-sign from Chief Treasurer Eleanor Vance upon commit.
              </p>
            )}
          </div>

          {/* Footer buttons */}
          <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || notional <= 0}
              className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 disabled:text-slate-600 text-white text-xs font-medium rounded-lg transition-colors cursor-pointer"
            >
              {isSubmitting ? (
                <span>Executing ISDA Confirmation...</span>
              ) : (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Execute &amp; Record to Ledger</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
