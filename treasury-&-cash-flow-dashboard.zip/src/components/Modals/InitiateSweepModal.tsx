import React, { useState } from 'react';
import { BankAccount, Currency, UserPersona } from '../../types/treasury';
import { formatCurrency } from '../../utils/formatters';
import { ArrowRight, ShieldCheck, AlertCircle, X } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  accounts: BankAccount[];
  activeUser: UserPersona;
  onConfirmSweep: (sweepData: {
    sourceAccountId: string;
    targetAccountId: string;
    amountNative: number;
    currency: Currency;
    memo: string;
  }) => void;
}

export const InitiateSweepModal: React.FC<Props> = ({
  isOpen,
  onClose,
  accounts,
  activeUser,
  onConfirmSweep,
}) => {
  const [sourceAccountId, setSourceAccountId] = useState<string>(accounts[0]?.id || '');
  const [targetAccountId, setTargetAccountId] = useState<string>(accounts[1]?.id || '');
  const [amountStr, setAmountStr] = useState<string>('2500000');
  const [memo, setMemo] = useState<string>('Daily Liquidity Concentration to Master Operating');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  if (!isOpen) return null;

  const sourceAcc = accounts.find((a) => a.id === sourceAccountId) || accounts[0];
  const targetAcc = accounts.find((a) => a.id === targetAccountId) || accounts[1];
  const amount = parseFloat(amountStr) || 0;
  const isHighValue = amount >= 500000;
  const requiresDualAuth = isHighValue && activeUser.role !== 'CHIEF_TREASURER';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (amount <= 0 || sourceAccountId === targetAccountId) return;

    setIsSubmitting(true);
    setTimeout(() => {
      onConfirmSweep({
        sourceAccountId,
        targetAccountId,
        amountNative: amount,
        currency: sourceAcc.currency,
        memo,
      });
      setIsSubmitting(false);
      onClose();
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90">
          <div>
            <h2 className="text-base font-semibold text-slate-100">Initiate Intercompany Cash Sweep</h2>
            <p className="text-xs text-slate-400 mt-0.5">Physical fund transfer between liquidity pools</p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 p-1.5 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Account Route Selector */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-300">Originating Account (Source)</label>
              <select
                value={sourceAccountId}
                onChange={(e) => setSourceAccountId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-hidden focus:border-cyan-500"
              >
                {accounts.map((acc) => (
                  <option key={acc.id} value={acc.id}>
                    {acc.bankName} ({acc.currency} {formatCurrency(acc.balanceNative, acc.currency, true)})
                  </option>
                ))}
              </select>
              <p className="text-[11px] text-slate-400">
                Available: {formatCurrency(sourceAcc?.balanceNative || 0, sourceAcc?.currency)}
              </p>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-300">Destination Account (Target)</label>
              <select
                value={targetAccountId}
                onChange={(e) => setTargetAccountId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-hidden focus:border-cyan-500"
              >
                {accounts
                  .filter((a) => a.id !== sourceAccountId)
                  .map((acc) => (
                    <option key={acc.id} value={acc.id}>
                      {acc.bankName} - {acc.accountName.substring(0, 24)}...
                    </option>
                  ))}
              </select>
              <p className="text-[11px] text-slate-400">
                Current: {formatCurrency(targetAcc?.balanceNative || 0, targetAcc?.currency)}
              </p>
            </div>
          </div>

          {/* Amount input */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center">
              <label className="text-xs font-medium text-slate-300">
                Sweep Amount ({sourceAcc.currency})
              </label>
              <div className="flex gap-2">
                {[1000000, 2500000, 5000000].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setAmountStr(preset.toString())}
                    className="text-[11px] px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 cursor-pointer"
                  >
                    +{formatCurrency(preset, sourceAcc.currency, true)}
                  </button>
                ))}
              </div>
            </div>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-slate-400 font-mono text-sm">
                {sourceAcc.currency}
              </span>
              <input
                type="number"
                min="1000"
                step="1000"
                value={amountStr}
                onChange={(e) => setAmountStr(e.target.value)}
                className="w-full pl-14 pr-4 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm font-mono tabular-nums text-slate-100 focus:outline-hidden focus:border-cyan-500"
                placeholder="0.00"
              />
            </div>
          </div>

          {/* Transfer Memo */}
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-slate-300">Compliance Memo & Audit Reason</label>
            <input
              type="text"
              value={memo}
              onChange={(e) => setMemo(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-hidden focus:border-cyan-500"
              placeholder="e.g. End of day target sweep"
            />
          </div>

          {/* Governance Notice */}
          <div className="p-3 bg-slate-950/80 rounded-lg border border-slate-800 text-xs space-y-1.5">
            <div className="flex items-center gap-2 text-slate-300">
              <ShieldCheck className="w-4 h-4 text-cyan-400 shrink-0" />
              <span className="font-medium">Cryptographic Ledger Commitment</span>
            </div>
            <p className="text-slate-400 text-[11px]">
              Upon execution, this transaction is cryptographically signed, hashed with SHA-256, and appended to the immutable treasury audit block.
            </p>
            {requiresDualAuth && (
              <div className="flex items-center gap-1.5 text-amber-400 text-[11px] pt-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>Notice: Transfers &ge; $500,000 will be auto-stamped with dual-authorization from Chief Treasurer.</span>
              </div>
            )}
          </div>

          {/* Footer buttons */}
          <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || amount <= 0 || amount > sourceAcc.balanceNative}
              className="flex items-center gap-2 px-4 py-2 bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-800 disabled:text-slate-600 text-white text-xs font-medium rounded-lg transition-colors cursor-pointer"
            >
              {isSubmitting ? (
                <span>Executing Sweep...</span>
              ) : (
                <>
                  <span>Sign &amp; Execute Sweep</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
