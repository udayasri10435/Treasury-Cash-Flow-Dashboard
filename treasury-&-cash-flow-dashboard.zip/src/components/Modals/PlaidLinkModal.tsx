import React, { useState } from 'react';
import { BankAccount, Currency, LegalEntity } from '../../types/treasury';
import { Building2, Check, Lock, ShieldCheck, X, ArrowRight, Loader2 } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  entities: LegalEntity[];
  onAccountLinked: (newAccount: BankAccount) => void;
}

const SUPPORTED_BANKS = [
  { code: 'JPM', name: 'JPMorgan Chase Bank, N.A.', region: 'Global' },
  { code: 'CITI', name: 'Citibank N.A. Institutional', region: 'Global' },
  { code: 'HSBC', name: 'HSBC Global Corporate Banking', region: 'UK / EMEA / APAC' },
  { code: 'BNP', name: 'BNP Paribas Corporate & Institutional', region: 'Europe' },
  { code: 'BARCLAYS', name: 'Barclays Corporate Banking', region: 'UK' },
  { code: 'DEUTSCHE', name: 'Deutsche Bank Global Transaction Banking', region: 'Global' },
];

export const PlaidLinkModal: React.FC<Props> = ({
  isOpen,
  onClose,
  entities,
  onAccountLinked,
}) => {
  const [step, setStep] = useState<'SELECT_BANK' | 'CREDENTIALS' | 'SELECT_ACCOUNTS' | 'CONNECTING' | 'SUCCESS'>('SELECT_BANK');
  const [selectedBank, setSelectedBank] = useState(SUPPORTED_BANKS[0]);
  const [entityId, setEntityId] = useState(entities[0]?.id || 'ent_us');
  const [accountType, setAccountType] = useState<'OPERATING' | 'MMF' | 'TREASURY'>('OPERATING');
  const [currency, setCurrency] = useState<Currency>('USD');
  const [initialBalance, setInitialBalance] = useState('18450000');

  if (!isOpen) return null;

  const handleNextToCredentials = (bank: typeof SUPPORTED_BANKS[0]) => {
    setSelectedBank(bank);
    setStep('CREDENTIALS');
  };

  const handleAuthorize = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('CONNECTING');
    setTimeout(() => {
      setStep('SUCCESS');
    }, 1200);
  };

  const handleFinish = () => {
    const randomMask = Math.floor(1000 + Math.random() * 9000).toString();
    const newAcc: BankAccount = {
      id: `acc_${selectedBank.code.toLowerCase()}_${Date.now()}`,
      entityId,
      bankName: selectedBank.name,
      bankCode: selectedBank.code as any,
      accountName: `${selectedBank.name.split(' ')[0]} ${accountType === 'OPERATING' ? 'Commercial Operating' : accountType === 'MMF' ? 'Institutional Yield MMF' : 'Treasury Reserve'}`,
      accountNumberMask: `•••• ${randomMask}`,
      iban: `${currency === 'USD' ? 'US82' : currency === 'EUR' ? 'NL91' : 'GB40'}${selectedBank.code}00${randomMask}991823`,
      currency,
      balanceNative: parseFloat(initialBalance) || 10000000,
      liquidityTier: accountType === 'MMF' ? 'TIER_2_SWEEP_MMF' : 'TIER_1_CASH',
      interestRateAPY: accountType === 'MMF' ? 5.15 : 4.60,
      lastSyncTimestamp: 'Just now',
      apiProvider: 'PLAID',
      status: 'ONLINE',
    };

    onAccountLinked(newAcc);
    setStep('SELECT_BANK');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-cyan-500/20 text-cyan-400 flex items-center justify-center text-xs font-mono font-bold">
              P
            </div>
            <div>
              <h2 className="text-sm font-semibold text-slate-100">Plaid Link for Enterprise Treasury</h2>
              <p className="text-[11px] text-slate-400">OAuth 2.0 Direct Core Banking API Feed</p>
            </div>
          </div>
          <button
            onClick={() => {
              setStep('SELECT_BANK');
              onClose();
            }}
            className="text-slate-400 hover:text-slate-200 p-1.5 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content depending on step */}
        <div className="p-6">
          {step === 'SELECT_BANK' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-300">
                Select your financial institution to establish an authenticated direct API balance &amp; transaction feed.
              </p>

              <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                {SUPPORTED_BANKS.map((bank) => (
                  <button
                    key={bank.code}
                    onClick={() => handleNextToCredentials(bank)}
                    className="w-full flex items-center justify-between p-3 rounded-lg border border-slate-800 bg-slate-950 hover:border-cyan-500/50 hover:bg-slate-850 transition-all text-left group cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-md bg-slate-800 flex items-center justify-center text-slate-200 font-mono text-xs font-bold">
                        {bank.code}
                      </div>
                      <div>
                        <div className="text-xs font-medium text-slate-200 group-hover:text-cyan-300">
                          {bank.name}
                        </div>
                        <div className="text-[11px] text-slate-400">{bank.region}</div>
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-cyan-400 group-hover:translate-x-0.5 transition-all" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {step === 'CREDENTIALS' && (
            <form onSubmit={handleAuthorize} className="space-y-4">
              <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-center gap-3">
                <Building2 className="w-5 h-5 text-cyan-400 shrink-0" />
                <div className="text-xs">
                  <div className="text-slate-200 font-medium">{selectedBank.name}</div>
                  <div className="text-slate-400 text-[11px]">OAuth 2.0 PKCE Sandbox Feed</div>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-slate-300">Link to Legal Entity</label>
                <select
                  value={entityId}
                  onChange={(e) => setEntityId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-hidden focus:border-cyan-500"
                >
                  {entities.map((e) => (
                    <option key={e.id} value={e.id}>
                      {e.code} - {e.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-slate-300">Account Purpose</label>
                  <select
                    value={accountType}
                    onChange={(e) => setAccountType(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-hidden focus:border-cyan-500"
                  >
                    <option value="OPERATING">Operating Cash (Tier 1)</option>
                    <option value="MMF">Yield MMF Sweep (Tier 2)</option>
                    <option value="TREASURY">Term Deposit (Tier 3)</option>
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-slate-300">Denomination</label>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value as Currency)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-hidden focus:border-cyan-500"
                  >
                    <option value="USD">USD ($)</option>
                    <option value="EUR">EUR (€)</option>
                    <option value="GBP">GBP (£)</option>
                    <option value="SGD">SGD (S$)</option>
                    <option value="JPY">JPY (¥)</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-slate-300">Initial Verified Balance ({currency})</label>
                <input
                  type="number"
                  value={initialBalance}
                  onChange={(e) => setInitialBalance(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs font-mono tabular-nums text-slate-100 focus:outline-hidden focus:border-cyan-500"
                />
              </div>

              <div className="flex items-center gap-2 text-[11px] text-slate-400 pt-1">
                <Lock className="w-3.5 h-3.5 text-cyan-400" />
                <span>Encrypted end-to-end with 256-bit AES &amp; TLS 1.3 mutual handshake.</span>
              </div>

              <div className="flex justify-between items-center pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setStep('SELECT_BANK')}
                  className="text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
                >
                  &larr; Back
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-medium rounded-lg cursor-pointer flex items-center gap-1.5"
                >
                  <span>Authenticate &amp; Link</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </form>
          )}

          {step === 'CONNECTING' && (
            <div className="py-12 flex flex-col items-center justify-center text-center space-y-3">
              <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
              <div className="text-sm font-medium text-slate-200">
                Negotiating OAuth Token &amp; Webhook Channels...
              </div>
              <p className="text-xs text-slate-400 max-w-xs">
                Exchanging temporary authorization code for persistent bank balance token.
              </p>
            </div>
          )}

          {step === 'SUCCESS' && (
            <div className="py-6 flex flex-col items-center justify-center text-center space-y-4">
              <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <Check className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-slate-100">API Connection Established</h3>
                <p className="text-xs text-slate-400 mt-1 max-w-sm">
                  {selectedBank.name} has been securely connected. Real-time balance streaming is now active and ready for cash sweeps.
                </p>
              </div>
              <button
                type="button"
                onClick={handleFinish}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium rounded-lg cursor-pointer transition-colors"
              >
                Integrate into Live Treasury Dashboard
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
