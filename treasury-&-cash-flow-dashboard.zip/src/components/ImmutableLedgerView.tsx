import React, { useState } from 'react';
import { LedgerBlock, UserPersona } from '../types/treasury';
import { verifyLedgerChain, VerificationResult } from '../utils/cryptoLedger';
import { formatCurrency, truncateHash } from '../utils/formatters';
import {
  ShieldCheck,
  ShieldAlert,
  CheckCircle2,
  Copy,
  Check,
  AlertTriangle,
  RotateCcw,
  FileCheck2,
  Lock,
  Search,
  ExternalLink,
} from 'lucide-react';

interface Props {
  chain: LedgerBlock[];
  activeUser: UserPersona;
  onOpenAuditExport: () => void;
  onTamperBlock: (index: number) => void;
  onRestoreChain: () => void;
}

export const ImmutableLedgerView: React.FC<Props> = ({
  chain,
  activeUser,
  onOpenAuditExport,
  onTamperBlock,
  onRestoreChain,
}) => {
  const [verificationResult, setVerificationResult] = useState<VerificationResult | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const [selectedBlock, setSelectedBlock] = useState<LedgerBlock | null>(null);
  const [copiedHash, setCopiedHash] = useState<string | null>(null);

  const handleVerify = async () => {
    setIsVerifying(true);
    const result = await verifyLedgerChain(chain);
    setTimeout(() => {
      setVerificationResult(result);
      setIsVerifying(false);
    }, 450);
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedHash(text);
    setTimeout(() => setCopiedHash(null), 1800);
  };

  const isChainCorrupted = chain.some((b) => b.isTampered);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="border border-slate-800 bg-slate-900/60 rounded-xl p-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-slate-800/80">
          <div>
            <div className="text-xs text-slate-400 font-medium tracking-wide">
              Cryptographic Treasury Ledger &amp; Immutable Audit Trail
            </div>
            <div className="flex items-center gap-3 mt-1">
              <span className="text-3xl font-bold font-mono tracking-tight text-slate-100 tabular-nums">
                {chain.length} Sealed Blocks
              </span>
              <span
                className={`text-xs font-mono font-medium px-2 py-0.5 rounded flex items-center gap-1.5 ${
                  !isChainCorrupted
                    ? 'text-emerald-400 bg-emerald-950/70 border border-emerald-900/50'
                    : 'text-rose-400 bg-rose-950/70 border border-rose-900/50'
                }`}
              >
                {!isChainCorrupted ? (
                  <>
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Cryptographically Sound &middot; SHA-256</span>
                  </>
                ) : (
                  <>
                    <ShieldAlert className="w-3.5 h-3.5" />
                    <span>Integrity Tamper Detected</span>
                  </>
                )}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-2 max-w-2xl">
              Every intercompany sweep, high-value disbursement, and FX contract is hashed in a forward-linked blockchain. Any byte mutation breaks downstream SHA-256 chain digests.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            {isChainCorrupted ? (
              <button
                onClick={onRestoreChain}
                className="flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium rounded-lg transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Restore Authentic Ledger</span>
              </button>
            ) : (
              <button
                onClick={() => onTamperBlock(1)}
                className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-rose-950/60 border border-slate-700 hover:border-rose-800 text-xs font-medium text-slate-300 hover:text-rose-300 rounded-lg transition-colors cursor-pointer"
                title="Simulates a fraudulent mutation to demonstrate tamper detection"
              >
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                <span>Simulate Fraudulent Tamper</span>
              </button>
            )}

            <button
              onClick={handleVerify}
              disabled={isVerifying}
              className="flex items-center gap-1.5 px-4 py-2 bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-800 text-white text-xs font-medium rounded-lg transition-colors cursor-pointer shadow-xs"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>{isVerifying ? 'Hashing Blocks...' : 'Verify Ledger Integrity'}</span>
            </button>

            <button
              onClick={onOpenAuditExport}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-750 border border-slate-700 text-xs font-medium text-slate-200 rounded-lg transition-colors cursor-pointer"
            >
              <FileCheck2 className="w-3.5 h-3.5 text-cyan-400" />
              <span>SOX 404 Dossier</span>
            </button>
          </div>
        </div>

        {/* Verification Result Notification */}
        {verificationResult && (
          <div
            className={`mt-4 p-4 rounded-lg border text-xs flex items-start justify-between gap-4 ${
              verificationResult.isValid
                ? 'bg-emerald-950/40 border-emerald-900/60 text-emerald-300'
                : 'bg-rose-950/50 border-rose-900/60 text-rose-300'
            }`}
          >
            <div className="flex items-start gap-3">
              {verificationResult.isValid ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
              ) : (
                <ShieldAlert className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              )}
              <div>
                <div className="font-semibold text-sm">
                  {verificationResult.isValid
                    ? '100% Cryptographic Verification Passed'
                    : 'Cryptographic Integrity Failure Detected'}
                </div>
                <div className="text-slate-300 text-[11px] mt-0.5">
                  {verificationResult.isValid ? (
                    <>
                      All {verificationResult.totalBlocksVerified} blocks re-computed and verified against native Web Crypto SHA-256 hash digests. Chain head: <code className="font-mono">{truncateHash(verificationResult.chainHeadHash)}</code>
                    </>
                  ) : (
                    <>
                      {verificationResult.reason} (Tampered block: #{verificationResult.tamperedBlockIndex})
                    </>
                  )}
                </div>
              </div>
            </div>
            <button
              onClick={() => setVerificationResult(null)}
              className="text-slate-400 hover:text-slate-200 text-xs cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        )}
      </div>

      {/* Blockchain Blocks List */}
      <div className="border border-slate-800 bg-slate-900/60 rounded-xl overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-800 flex items-center justify-between">
          <h2 className="text-xs font-semibold text-slate-200 tracking-wide">
            Immutable Audit Trail &middot; Sequential Block Chain
          </h2>
          <span className="text-[11px] text-slate-400 font-mono">Consensus: Corporate Treasury Multi-Sig</span>
        </div>

        <div className="divide-y divide-slate-800/70">
          {chain.map((block) => {
            const isTampered = block.isTampered;
            const isGenesis = block.blockIndex === 0;

            return (
              <div
                key={block.blockIndex}
                className={`p-4 transition-colors ${
                  isTampered
                    ? 'bg-rose-950/30 hover:bg-rose-950/40'
                    : 'hover:bg-slate-800/30'
                }`}
              >
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 text-xs">
                  {/* Left Block Badge & Info */}
                  <div className="flex items-start gap-3">
                    <div
                      className={`w-9 h-9 rounded-lg flex items-center justify-center font-mono font-bold text-xs shrink-0 ${
                        isTampered
                          ? 'bg-rose-900/60 text-rose-300 border border-rose-700'
                          : isGenesis
                          ? 'bg-purple-900/50 text-purple-300 border border-purple-700/60'
                          : 'bg-slate-800 text-cyan-300 border border-slate-700'
                      }`}
                    >
                      #{block.blockIndex}
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-200">{block.eventType.replace(/_/g, ' ')}</span>
                        <span className="text-slate-400 font-mono text-[10px]">[{block.entityCode}]</span>
                        {isTampered && (
                          <span className="text-[10px] font-mono bg-rose-900 text-rose-200 px-1.5 py-0.5 rounded font-bold">
                            TAMPERED
                          </span>
                        )}
                      </div>
                      <p className="text-slate-300 text-xs">{block.description}</p>
                      <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-400">
                        <span>Initiated by: <strong className="text-slate-200">{block.actor}</strong></span>
                        {block.approver && (
                          <>
                            <span aria-hidden="true">&middot;</span>
                            <span>Approver: <strong className="text-slate-200">{block.approver}</strong></span>
                          </>
                        )}
                        <span aria-hidden="true">&middot;</span>
                        <span className="font-mono">{new Date(block.timestamp).toLocaleString()}</span>
                      </div>
                    </div>
                  </div>

                  {/* Right Amount & Hashes */}
                  <div className="flex flex-col lg:items-end justify-center space-y-1 font-mono shrink-0 pl-12 lg:pl-0">
                    <div className="text-sm font-bold text-slate-100 tabular-nums">
                      {block.amountUSD > 0 ? formatCurrency(block.amountUSD, 'USD') : '—'}
                    </div>

                    <div className="flex items-center gap-2 text-[10px] text-slate-400">
                      <span>Prev: <code className="text-slate-400">{truncateHash(block.prevHash, 6, 4)}</code></span>
                      <span>Hash: <code className={isTampered ? 'text-rose-400 font-bold' : 'text-cyan-400'}>{truncateHash(block.hash, 6, 4)}</code></span>
                      <button
                        onClick={() => handleCopy(block.hash)}
                        className="text-slate-400 hover:text-slate-200 p-0.5 rounded cursor-pointer"
                        title="Copy full SHA-256 hash"
                      >
                        {copiedHash === block.hash ? (
                          <Check className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>
                    </div>

                    <button
                      onClick={() => setSelectedBlock(block)}
                      className="text-[11px] text-cyan-400 hover:text-cyan-300 font-sans cursor-pointer self-start lg:self-end"
                    >
                      Inspect Raw Payload &rarr;
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Block Payload Inspector Modal */}
      {selectedBlock && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
          <div className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-xl shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950">
              <div className="flex items-center gap-2">
                <Lock className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-semibold text-slate-100">
                  Block #{selectedBlock.blockIndex} Cryptographic Proof
                </h3>
              </div>
              <button
                onClick={() => setSelectedBlock(null)}
                className="text-slate-400 hover:text-slate-200 text-xs cursor-pointer"
              >
                Close
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs font-mono">
              <div className="space-y-1">
                <div className="text-slate-400 text-[11px]">SHA-256 Block Digest:</div>
                <div className="p-2.5 bg-slate-950 border border-slate-800 rounded text-cyan-400 break-all select-all">
                  {selectedBlock.hash}
                </div>
              </div>

              <div className="space-y-1">
                <div className="text-slate-400 text-[11px]">Previous Block Hash:</div>
                <div className="p-2 bg-slate-950 border border-slate-800 rounded text-slate-300 break-all">
                  {selectedBlock.prevHash}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 text-[11px]">
                <div>
                  <span className="text-slate-400">Merkle Root:</span>
                  <div className="text-slate-200 truncate mt-0.5">{selectedBlock.merkleRoot}</div>
                </div>
                <div>
                  <span className="text-slate-400">Nonce:</span>
                  <div className="text-slate-200 mt-0.5">{selectedBlock.nonce}</div>
                </div>
              </div>

              <div className="space-y-1 pt-2 border-t border-slate-800">
                <div className="text-slate-400 text-[11px]">Canonical Payload:</div>
                <pre className="p-3 bg-slate-950 border border-slate-800 rounded text-[11px] text-slate-300 max-h-48 overflow-y-auto leading-relaxed">
                  {JSON.stringify(selectedBlock, null, 2)}
                </pre>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
