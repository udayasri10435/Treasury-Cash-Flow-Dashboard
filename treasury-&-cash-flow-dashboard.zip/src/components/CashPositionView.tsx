import React, { useState } from 'react';
import {
  BankAccount,
  Currency,
  FXRate,
  LegalEntity,
  LiquidityTier,
  IntercompanySweepRule,
  UserPersona,
} from '../types/treasury';
import { formatCurrency, convertToUSD, convertFromUSD } from '../utils/formatters';
import {
  ArrowDownRight,
  ArrowUpRight,
  Building2,
  RefreshCw,
  Send,
  Zap,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';

interface Props {
  accounts: BankAccount[];
  entities: LegalEntity[];
  sweepRules: IntercompanySweepRule[];
  fxRates: FXRate[];
  baseCurrency: Currency;
  activeUser: UserPersona;
  onOpenSweepModal: () => void;
  onExecuteAutoBalancing: () => void;
  onRefreshFeed: () => void;
}

export const CashPositionView: React.FC<Props> = ({
  accounts,
  entities,
  sweepRules,
  fxRates,
  baseCurrency,
  activeUser,
  onOpenSweepModal,
  onExecuteAutoBalancing,
  onRefreshFeed,
}) => {
  const [selectedEntityId, setSelectedEntityId] = useState<string>('ALL');
  const [selectedTier, setSelectedTier] = useState<LiquidityTier | 'ALL'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [isRefreshing, setIsRefreshing] = useState(false);

  const filteredAccounts = accounts.filter((acc) => {
    if (selectedEntityId !== 'ALL' && acc.entityId !== selectedEntityId) return false;
    if (selectedTier !== 'ALL' && acc.liquidityTier !== selectedTier) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match =
        acc.bankName.toLowerCase().includes(q) ||
        acc.accountName.toLowerCase().includes(q) ||
        acc.iban.toLowerCase().includes(q) ||
        acc.currency.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  // Calculate totals in Base Currency
  const totalCashUSD = accounts
    .filter((a) => a.liquidityTier !== 'TIER_4_CREDIT_FACILITY')
    .reduce((sum, a) => sum + convertToUSD(a.balanceNative, a.currency, fxRates), 0);

  const tier1USD = accounts
    .filter((a) => a.liquidityTier === 'TIER_1_CASH')
    .reduce((sum, a) => sum + convertToUSD(a.balanceNative, a.currency, fxRates), 0);

  const tier2USD = accounts
    .filter((a) => a.liquidityTier === 'TIER_2_SWEEP_MMF')
    .reduce((sum, a) => sum + convertToUSD(a.balanceNative, a.currency, fxRates), 0);

  const tier3USD = accounts
    .filter((a) => a.liquidityTier === 'TIER_3_TERM_DEPOSIT')
    .reduce((sum, a) => sum + convertToUSD(a.balanceNative, a.currency, fxRates), 0);

  const creditHeadroomUSD = accounts
    .filter((a) => a.liquidityTier === 'TIER_4_CREDIT_FACILITY')
    .reduce((sum, a) => sum + convertToUSD(a.balanceNative, a.currency, fxRates), 0);

  const totalBase = convertFromUSD(totalCashUSD, baseCurrency, fxRates);
  const tier1Base = convertFromUSD(tier1USD, baseCurrency, fxRates);
  const tier2Base = convertFromUSD(tier2USD, baseCurrency, fxRates);
  const tier3Base = convertFromUSD(tier3USD, baseCurrency, fxRates);
  const creditHeadroomBase = convertFromUSD(creditHeadroomUSD, baseCurrency, fxRates);

  const handleRefresh = () => {
    setIsRefreshing(true);
    onRefreshFeed();
    setTimeout(() => setIsRefreshing(false), 800);
  };

  return (
    <div className="space-y-6">
      {/* Top Liquidity Overview Banner */}
      <div className="border border-slate-800 bg-slate-900/60 rounded-xl p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-800/80">
          <div>
            <div className="text-xs text-slate-400 font-medium tracking-wide">
              Global Consolidated Liquidity Position &middot; Real-Time
            </div>
            <div className="text-3xl md:text-4xl font-bold font-mono tracking-tight text-slate-100 mt-1 tabular-nums">
              {formatCurrency(totalBase, baseCurrency)}
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-400 mt-2">
              <span className="text-emerald-400 font-mono font-medium flex items-center">
                <ArrowUpRight className="w-3.5 h-3.5" />
                +2.4% vs last week
              </span>
              <span aria-hidden="true">&middot;</span>
              <span>Available Credit Headroom: {formatCurrency(creditHeadroomBase, baseCurrency, true)}</span>
              <span aria-hidden="true">&middot;</span>
              <span>Blended Yield: 4.88% APY</span>
            </div>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              onClick={handleRefresh}
              className="p-2 text-slate-400 hover:text-slate-200 border border-slate-800 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              title="Refresh Bank Polling Feeds"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-cyan-400' : ''}`} />
            </button>
            <button
              onClick={onExecuteAutoBalancing}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-750 border border-slate-700 text-xs font-medium text-slate-200 rounded-lg transition-colors cursor-pointer"
            >
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>Run ZBA Sweep Rule</span>
            </button>
            <button
              onClick={onOpenSweepModal}
              disabled={!activeUser.permissions.canInitiateSweeps}
              className="flex items-center gap-1.5 px-4 py-2 bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-800 disabled:text-slate-600 text-white text-xs font-medium rounded-lg transition-colors cursor-pointer shadow-xs"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Initiate Sweep</span>
            </button>
          </div>
        </div>

        {/* Liquidity Tier Breakdown */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 pt-5">
          <div className="p-3 bg-slate-950/70 border border-slate-800/80 rounded-lg">
            <div className="text-[11px] text-slate-400 font-medium">Tier 1: Instant Cash (&lt;24h)</div>
            <div className="text-lg font-mono font-semibold text-slate-100 mt-1 tabular-nums">
              {formatCurrency(tier1Base, baseCurrency, true)}
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              {((tier1USD / totalCashUSD) * 100).toFixed(1)}% of total &middot; 4.10% avg
            </div>
          </div>

          <div className="p-3 bg-slate-950/70 border border-slate-800/80 rounded-lg">
            <div className="text-[11px] text-slate-400 font-medium">Tier 2: Yield MMF Sweeps</div>
            <div className="text-lg font-mono font-semibold text-cyan-400 mt-1 tabular-nums">
              {formatCurrency(tier2Base, baseCurrency, true)}
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              {((tier2USD / totalCashUSD) * 100).toFixed(1)}% of total &middot; 5.22% avg
            </div>
          </div>

          <div className="p-3 bg-slate-950/70 border border-slate-800/80 rounded-lg">
            <div className="text-[11px] text-slate-400 font-medium">Tier 3: Term Deposits (90d)</div>
            <div className="text-lg font-mono font-semibold text-slate-200 mt-1 tabular-nums">
              {formatCurrency(tier3Base, baseCurrency, true)}
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              {((tier3USD / totalCashUSD) * 100).toFixed(1)}% of total &middot; 5.35% APY
            </div>
          </div>

          <div className="p-3 bg-slate-950/70 border border-slate-800/80 rounded-lg">
            <div className="text-[11px] text-slate-400 font-medium">Tier 4: Credit Headroom</div>
            <div className="text-lg font-mono font-semibold text-purple-400 mt-1 tabular-nums">
              {formatCurrency(creditHeadroomBase, baseCurrency, true)}
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">Deutsche Bank Syndicated Facility</div>
          </div>
        </div>
      </div>

      {/* Filter and Entity Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Entity Tabs */}
        <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg overflow-x-auto text-xs">
          <button
            onClick={() => setSelectedEntityId('ALL')}
            className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
              selectedEntityId === 'ALL'
                ? 'bg-slate-800 text-slate-100 shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            All Entities ({accounts.length})
          </button>
          {entities.map((ent) => (
            <button
              key={ent.id}
              onClick={() => setSelectedEntityId(ent.id)}
              className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
                selectedEntityId === ent.id
                  ? 'bg-slate-800 text-slate-100 shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {ent.code}
            </button>
          ))}
        </div>

        {/* Search input */}
        <div className="relative">
          <input
            type="text"
            placeholder="Search bank, IBAN, currency..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full sm:w-64 px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-200 focus:outline-hidden focus:border-cyan-500 placeholder:text-slate-500"
          />
        </div>
      </div>

      {/* Bank Accounts High-Density Grid */}
      <div className="border border-slate-800 bg-slate-900/60 rounded-xl overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-800 flex items-center justify-between">
          <h2 className="text-xs font-semibold text-slate-200 tracking-wide">
            Real-Time Bank Accounts &amp; Treasury Cash Pools
          </h2>
          <span className="text-[11px] text-slate-400 font-mono">
            {filteredAccounts.length} Connected Accounts
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 text-[11px] font-medium">
                <th className="py-2.5 px-4">Financial Institution</th>
                <th className="py-2.5 px-4">Account &amp; Purpose</th>
                <th className="py-2.5 px-4">Entity</th>
                <th className="py-2.5 px-4 text-right">Native Balance</th>
                <th className="py-2.5 px-4 text-right">Eq. ({baseCurrency})</th>
                <th className="py-2.5 px-4 text-right">APY</th>
                <th className="py-2.5 px-4">Feed Protocol</th>
                <th className="py-2.5 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredAccounts.map((acc) => {
                const ent = entities.find((e) => e.id === acc.entityId);
                const eqBase = convertFromUSD(
                  convertToUSD(acc.balanceNative, acc.currency, fxRates),
                  baseCurrency,
                  fxRates
                );

                return (
                  <tr key={acc.id} className="hover:bg-slate-800/40 transition-colors group">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded bg-slate-800 border border-slate-700/80 flex items-center justify-center font-mono font-bold text-[10px] text-slate-200">
                          {acc.bankCode}
                        </div>
                        <div>
                          <div className="font-medium text-slate-200">{acc.bankName}</div>
                          <div className="text-[10px] text-slate-400 font-mono">{acc.accountNumberMask}</div>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-4">
                      <div className="text-slate-200 font-medium">{acc.accountName}</div>
                      <div className="text-[10px] text-slate-400 font-mono truncate max-w-[180px]">
                        {acc.iban}
                      </div>
                    </td>

                    <td className="py-3 px-4">
                      <div className="text-slate-200">{ent?.code}</div>
                      <div className="text-[10px] text-slate-400 truncate max-w-[120px]">
                        {ent?.jurisdiction.split(',')[0]}
                      </div>
                    </td>

                    <td className="py-3 px-4 text-right font-mono tabular-nums">
                      <div className="text-slate-100 font-medium">
                        {formatCurrency(acc.balanceNative, acc.currency)}
                      </div>
                      <div className="text-[10px] text-slate-400">{acc.currency} Native</div>
                    </td>

                    <td className="py-3 px-4 text-right font-mono tabular-nums">
                      <div className="text-cyan-300 font-medium">
                        {formatCurrency(eqBase, baseCurrency)}
                      </div>
                      <div className="text-[10px] text-slate-400">Consolidated</div>
                    </td>

                    <td className="py-3 px-4 text-right font-mono tabular-nums text-emerald-400">
                      {acc.interestRateAPY > 0 ? `${acc.interestRateAPY.toFixed(2)}%` : '—'}
                    </td>

                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                        <span className="text-[11px] text-slate-300 font-mono">{acc.apiProvider}</span>
                      </div>
                      <div className="text-[10px] text-slate-400">{acc.lastSyncTimestamp}</div>
                    </td>

                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={onOpenSweepModal}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-slate-100 rounded text-[11px] font-medium transition-colors cursor-pointer border border-slate-700"
                      >
                        Sweep
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Intercompany Sweeping Rules and Cash Concentration Matrix */}
      <div className="border border-slate-800 bg-slate-900/60 rounded-xl p-5">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div>
            <h2 className="text-xs font-semibold text-slate-200 tracking-wide">
              Automated Cash Concentration &amp; Intercompany Sweeps
            </h2>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Zero-Balance Accounts (ZBA) and target balancing rules across subsidiary legal entities
            </p>
          </div>
          <button
            onClick={onExecuteAutoBalancing}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg border border-slate-700 transition-colors cursor-pointer"
          >
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>Trigger Concentration Run</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
          {sweepRules.map((rule) => {
            const srcAcc = accounts.find((a) => a.id === rule.sourceAccountId);
            const tgtAcc = accounts.find((a) => a.id === rule.targetAccountId);

            return (
              <div
                key={rule.id}
                className="p-3.5 bg-slate-950/70 border border-slate-800 rounded-lg space-y-2 text-xs"
              >
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-200 font-mono text-[11px]">
                    {rule.ruleType.replace('_', ' ')}
                  </span>
                  <span className="text-[10px] text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    Active
                  </span>
                </div>

                <div className="text-[11px] text-slate-400 space-y-0.5">
                  <div className="flex justify-between">
                    <span>Source:</span>
                    <span className="text-slate-200 font-mono">{srcAcc?.bankName.split(' ')[0]} ({rule.currency})</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Target:</span>
                    <span className="text-slate-200 font-mono">{tgtAcc?.bankName.split(' ')[0]}</span>
                  </div>
                  <div className="flex justify-between pt-1 border-t border-slate-800/80">
                    <span>Target Threshold:</span>
                    <span className="text-cyan-300 font-mono tabular-nums">
                      {formatCurrency(rule.targetThresholdNative, rule.currency, true)}
                    </span>
                  </div>
                </div>

                <div className="text-[10px] text-slate-400 pt-1">
                  Last executed: {rule.lastExecuted || 'Pending cycle'}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
