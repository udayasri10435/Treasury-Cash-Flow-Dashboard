import React, { useState } from 'react';
import { Currency, UserPersona, UserRole } from '../types/treasury';
import { USER_PERSONAS } from '../data/initialTreasuryData';
import { Shield, ChevronDown, Check } from 'lucide-react';

export type ActiveTab = 'CASH_POSITION' | 'FORECASTING' | 'FX_EXPOSURE' | 'IMMUTABLE_LEDGER' | 'BANK_CONNECTORS';

interface Props {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  baseCurrency: Currency;
  setBaseCurrency: (c: Currency) => void;
  activeUser: UserPersona;
  setActiveUser: (u: UserPersona) => void;
  onOpenAuditExport: () => void;
}

export const TopNav: React.FC<Props> = ({
  activeTab,
  setActiveTab,
  baseCurrency,
  setBaseCurrency,
  activeUser,
  setActiveUser,
  onOpenAuditExport,
}) => {
  const [roleMenuOpen, setRoleMenuOpen] = useState(false);

  const navItems: { id: ActiveTab; label: string }[] = [
    { id: 'CASH_POSITION', label: 'Cash Position' },
    { id: 'FORECASTING', label: 'Cash Forecast' },
    { id: 'FX_EXPOSURE', label: 'FX Exposure' },
    { id: 'IMMUTABLE_LEDGER', label: 'Immutable Ledger' },
    { id: 'BANK_CONNECTORS', label: 'Bank Feeds' },
  ];

  const currencies: Currency[] = ['USD', 'EUR', 'GBP', 'JPY', 'SGD'];

  return (
    <header className="border-b border-slate-800 bg-slate-950/95 sticky top-0 z-40 px-6 py-3.5 backdrop-blur-md">
      <div className="flex items-center justify-between gap-4 max-w-7xl mx-auto">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="/"
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('CASH_POSITION');
          }}
          className="text-base font-bold tracking-tight text-slate-100 whitespace-nowrap hover:text-cyan-400 transition-colors"
        >
          Apex Treasury OS
        </a>

        {/* Zone 2: 4-6 clean text navigation links */}
        <nav className="hidden md:flex items-center gap-7 text-xs font-medium text-slate-400">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`whitespace-nowrap transition-colors relative py-1 cursor-pointer ${
                  isActive
                    ? 'text-cyan-400 font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {item.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-cyan-500 rounded-full" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1-2 primary actions (Consolidated currency + Role switcher) */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Base Currency Segmented Picker */}
          <div className="flex items-center bg-slate-900 border border-slate-800 rounded-lg p-0.5 text-[11px] font-mono">
            {currencies.map((curr) => (
              <button
                key={curr}
                onClick={() => setBaseCurrency(curr)}
                className={`px-2 py-1 rounded transition-colors cursor-pointer ${
                  baseCurrency === curr
                    ? 'bg-slate-800 text-cyan-300 font-medium shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {curr}
              </button>
            ))}
          </div>

          {/* User Persona / Role Switcher */}
          <div className="relative">
            <button
              onClick={() => setRoleMenuOpen(!roleMenuOpen)}
              className="flex items-center gap-2 px-2.5 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg text-xs transition-colors cursor-pointer"
            >
              <div
                className={`w-5 h-5 rounded-full bg-gradient-to-tr ${activeUser.colorScheme} flex items-center justify-center text-[10px] font-bold text-white shadow-xs`}
              >
                {activeUser.avatarInitials}
              </div>
              <div className="hidden sm:block text-left text-[11px] leading-tight">
                <div className="font-medium text-slate-200 truncate max-w-[110px]">{activeUser.name}</div>
                <div className="text-[10px] text-slate-400 truncate max-w-[110px]">{activeUser.roleTitle.split('&')[0]}</div>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {/* Dropdown Menu */}
            {roleMenuOpen && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setRoleMenuOpen(false)}
                />
                <div className="absolute right-0 mt-2 w-72 bg-slate-900 border border-slate-800 rounded-xl shadow-xl z-50 p-2 space-y-1">
                  <div className="px-3 py-2 border-b border-slate-800">
                    <div className="text-xs font-semibold text-slate-200">Role-Based Access Control</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">Switch active operational persona</div>
                  </div>

                  {USER_PERSONAS.map((persona) => {
                    const isSelected = activeUser.id === persona.id;
                    return (
                      <button
                        key={persona.id}
                        onClick={() => {
                          setActiveUser(persona);
                          setRoleMenuOpen(false);
                        }}
                        className={`w-full flex items-start gap-2.5 p-2 rounded-lg text-left transition-colors cursor-pointer ${
                          isSelected ? 'bg-slate-800/90 text-cyan-300' : 'hover:bg-slate-800/50 text-slate-300'
                        }`}
                      >
                        <div
                          className={`w-6 h-6 rounded-full bg-gradient-to-tr ${persona.colorScheme} flex items-center justify-center text-[10px] font-bold text-white shrink-0 mt-0.5`}
                        >
                          {persona.avatarInitials}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="text-xs font-medium flex items-center justify-between">
                            <span className="truncate">{persona.name}</span>
                            {isSelected && <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />}
                          </div>
                          <div className="text-[11px] text-slate-400 truncate">{persona.roleTitle}</div>
                          <div className="text-[10px] text-slate-400 font-mono mt-0.5">{persona.department}</div>
                        </div>
                      </button>
                    );
                  })}

                  <div className="pt-1.5 border-t border-slate-800">
                    <button
                      onClick={() => {
                        setRoleMenuOpen(false);
                        onOpenAuditExport();
                      }}
                      className="w-full text-center py-1.5 text-xs text-cyan-400 hover:text-cyan-300 cursor-pointer font-medium"
                    >
                      Export SOX 404 Audit Dossier
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
