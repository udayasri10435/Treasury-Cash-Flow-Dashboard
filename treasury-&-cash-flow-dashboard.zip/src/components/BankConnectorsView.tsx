import React, { useState } from 'react';
import { BankAccount, BankConnectorStatus, UserPersona } from '../types/treasury';
import {
  Building2,
  PlugZap,
  UploadCloud,
  CheckCircle2,
  RefreshCw,
  ShieldCheck,
  Server,
  Activity,
  ArrowRight,
} from 'lucide-react';

interface Props {
  connectors: BankConnectorStatus[];
  accounts: BankAccount[];
  activeUser: UserPersona;
  onOpenPlaidLink: () => void;
  onOpenSwiftParser: () => void;
  onPollAllFeeds: () => void;
}

export const BankConnectorsView: React.FC<Props> = ({
  connectors,
  accounts,
  activeUser,
  onOpenPlaidLink,
  onOpenSwiftParser,
  onPollAllFeeds,
}) => {
  const [isPolling, setIsPolling] = useState(false);

  const handleSyncAll = () => {
    setIsPolling(true);
    onPollAllFeeds();
    setTimeout(() => {
      setIsPolling(false);
    }, 900);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="border border-slate-800 bg-slate-900/60 rounded-xl p-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-slate-800/80">
          <div>
            <div className="text-xs text-slate-400 font-medium tracking-wide">
              Open Banking &amp; Host-to-Host Integration Feeds
            </div>
            <div className="flex items-center gap-3 mt-1">
              <span className="text-3xl font-bold font-mono tracking-tight text-slate-100 tabular-nums">
                {accounts.length} Active Feeds Connected
              </span>
              <span className="text-xs font-mono font-medium px-2 py-0.5 rounded bg-emerald-950/70 text-emerald-400 border border-emerald-900/50 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Webhooks Healthy (0 Dropouts)</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-2 max-w-2xl">
              Bidirectional treasury connectivity via Plaid Enterprise Link, Yodlee FastLink 4.0, and direct SWIFTNet FIN / ISO 20022 XML pipelines.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              onClick={handleSyncAll}
              disabled={isPolling}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-750 border border-slate-700 text-xs font-medium text-slate-200 rounded-lg transition-colors cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isPolling ? 'animate-spin text-cyan-400' : ''}`} />
              <span>{isPolling ? 'Polling Webhooks...' : 'Poll All Bank Feeds'}</span>
            </button>

            <button
              onClick={onOpenSwiftParser}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-750 border border-slate-700 text-xs font-medium text-slate-200 rounded-lg transition-colors cursor-pointer"
            >
              <UploadCloud className="w-3.5 h-3.5 text-cyan-400" />
              <span>Ingest SWIFT MT940</span>
            </button>

            <button
              onClick={onOpenPlaidLink}
              disabled={!activeUser.permissions.canConnectBankAPIs}
              className="flex items-center gap-1.5 px-4 py-2 bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-800 disabled:text-slate-600 text-white text-xs font-medium rounded-lg transition-colors cursor-pointer shadow-xs"
            >
              <PlugZap className="w-3.5 h-3.5" />
              <span>Plaid Link New Bank</span>
            </button>
          </div>
        </div>

        {/* Connectors Overview Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-5">
          {connectors.map((conn) => (
            <div
              key={conn.id}
              className="p-4 bg-slate-950/70 border border-slate-800 rounded-lg space-y-3"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-xs font-semibold text-slate-200">{conn.name}</div>
                  <div className="text-[11px] text-slate-400 font-mono mt-0.5">{conn.protocol}</div>
                </div>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse mt-1" />
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs pt-2 border-t border-slate-800/60 font-mono">
                <div>
                  <div className="text-slate-400 text-[10px]">Polled Latency</div>
                  <div className="text-emerald-400 font-medium">{conn.latencyMs}ms</div>
                </div>
                <div>
                  <div className="text-slate-400 text-[10px]">Active Accounts</div>
                  <div className="text-slate-200 font-medium">{conn.activeAccounts} Accounts</div>
                </div>
                <div>
                  <div className="text-slate-400 text-[10px]">Last Polled</div>
                  <div className="text-slate-300">{conn.lastPolled}</div>
                </div>
                <div>
                  <div className="text-slate-400 text-[10px]">Webhook Health</div>
                  <div className="text-cyan-400 font-medium">{conn.webhookStatus}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Connected Financial Institutions & Bank APIs */}
      <div className="border border-slate-800 bg-slate-900/60 rounded-xl overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-800 flex items-center justify-between">
          <h2 className="text-xs font-semibold text-slate-200 tracking-wide">
            Enterprise Banking Partners &amp; Integration Channels
          </h2>
          <span className="text-[11px] text-slate-400 font-mono">Mutual TLS / OAuth 2.0 PKCE / SWIFTNet</span>
        </div>

        <div className="divide-y divide-slate-800/60">
          {accounts.map((acc) => (
            <div key={acc.id} className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded bg-slate-800 border border-slate-700 flex items-center justify-center font-mono font-bold text-xs text-slate-200 shrink-0">
                  {acc.bankCode}
                </div>
                <div>
                  <div className="font-semibold text-slate-200">{acc.bankName}</div>
                  <div className="text-slate-400 text-[11px] font-mono">
                    {acc.accountName} &middot; {acc.accountNumberMask} &middot; {acc.iban}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-6 text-[11px] font-mono shrink-0">
                <div>
                  <span className="text-slate-400">Provider: </span>
                  <span className="text-cyan-300 font-medium">{acc.apiProvider}</span>
                </div>
                <div>
                  <span className="text-slate-400">Sync Status: </span>
                  <span className="text-emerald-400 font-medium">{acc.status}</span>
                </div>
                <div className="text-slate-400">
                  <span>Last Handshake: </span>
                  <span className="text-slate-200">{acc.lastSyncTimestamp}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Security Architecture & Compliance Box */}
      <div className="p-5 border border-slate-800 bg-slate-900/40 rounded-xl space-y-3">
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-200">
          <ShieldCheck className="w-4 h-4 text-cyan-400" />
          <span>Institutional Open Banking Security Standards</span>
        </div>
        <p className="text-xs text-slate-400 leading-relaxed">
          All financial institution integrations adhere to SOC 2 Type II, ISO 27001, and PCI-DSS Level 1 specifications. Direct host-to-host integrations leverage FAPI (Financial-grade API) read/write profiles with Hardware Security Module (HSM) client credentials.
        </p>
      </div>
    </div>
  );
};
