import { LedgerBlock } from '../types/treasury';

/**
 * Computes SHA-256 hash using the native browser Web Crypto API.
 */
export async function computeSHA256(message: string): Promise<string> {
  if (typeof window !== 'undefined' && window.crypto && window.crypto.subtle) {
    const encoder = new TextEncoder();
    const data = encoder.encode(message);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  } else {
    // Pure fallback if crypto.subtle is not accessible
    let hash = 0;
    for (let i = 0; i < message.length; i++) {
      const char = message.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash = hash & hash;
    }
    return Math.abs(hash).toString(16).padStart(64, '0');
  }
}

/**
 * Formats a block payload into a canonical string for cryptographic hashing.
 */
export function getCanonicalBlockString(block: Omit<LedgerBlock, 'hash'>): string {
  return JSON.stringify({
    blockIndex: block.blockIndex,
    timestamp: block.timestamp,
    eventType: block.eventType,
    entityCode: block.entityCode,
    description: block.description,
    amountUSD: block.amountUSD,
    actor: block.actor,
    actorRole: block.actorRole,
    approver: block.approver || '',
    prevHash: block.prevHash,
    nonce: block.nonce,
    merkleRoot: block.merkleRoot,
  });
}

/**
 * Mines or seals a new block by computing its cryptographic hash.
 */
export async function sealBlock(blockData: Omit<LedgerBlock, 'hash'>): Promise<LedgerBlock> {
  const payload = getCanonicalBlockString(blockData);
  const hash = await computeSHA256(payload);
  return {
    ...blockData,
    hash,
  };
}

export interface VerificationResult {
  isValid: boolean;
  tamperedBlockIndex?: number;
  reason?: string;
  totalBlocksVerified: number;
  chainHeadHash: string;
}

/**
 * Mathematically validates the cryptographic integrity of the entire ledger chain.
 */
export async function verifyLedgerChain(chain: LedgerBlock[]): Promise<VerificationResult> {
  if (!chain || chain.length === 0) {
    return { isValid: false, reason: 'Empty ledger chain', totalBlocksVerified: 0, chainHeadHash: '' };
  }

  for (let i = 0; i < chain.length; i++) {
    const currentBlock = chain[i];

    // Check genesis block rule
    if (i === 0) {
      if (currentBlock.prevHash !== '0000000000000000000000000000000000000000000000000000000000000000') {
        return {
          isValid: false,
          tamperedBlockIndex: 0,
          reason: 'Genesis block previous hash is corrupted.',
          totalBlocksVerified: 0,
          chainHeadHash: currentBlock.hash,
        };
      }
    } else {
      const prevBlock = chain[i - 1];
      // Verify back-link to previous block hash
      if (currentBlock.prevHash !== prevBlock.hash) {
        return {
          isValid: false,
          tamperedBlockIndex: i,
          reason: `Broken chain link at Block #${currentBlock.blockIndex}: prevHash does not match Block #${prevBlock.blockIndex} hash.`,
          totalBlocksVerified: i,
          chainHeadHash: chain[chain.length - 1].hash,
        };
      }
    }

    // Verify cryptographic self-consistency (hash must match canonical payload)
    const { hash: storedHash, isTampered, ...blockDataWithoutHash } = currentBlock;
    const computedHash = await computeSHA256(getCanonicalBlockString(blockDataWithoutHash));

    if (computedHash !== storedHash) {
      return {
        isValid: false,
        tamperedBlockIndex: i,
        reason: `Cryptographic digest mismatch at Block #${currentBlock.blockIndex}. Computed: ${computedHash.substring(0, 12)}... Stored: ${storedHash.substring(0, 12)}...`,
        totalBlocksVerified: i,
        chainHeadHash: chain[chain.length - 1].hash,
      };
    }
  }

  return {
    isValid: true,
    totalBlocksVerified: chain.length,
    chainHeadHash: chain[chain.length - 1].hash,
  };
}
