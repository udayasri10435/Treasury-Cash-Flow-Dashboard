import { Currency, FXRate } from '../types/treasury';

export function formatCurrency(
  amount: number,
  currency: Currency = 'USD',
  compact: boolean = false
): string {
  const symbolMap: Record<Currency, string> = {
    USD: '$',
    EUR: '€',
    GBP: '£',
    JPY: '¥',
    SGD: 'S$',
  };

  const symbol = symbolMap[currency] || '$';

  if (compact) {
    const abs = Math.abs(amount);
    const sign = amount < 0 ? '-' : '';
    if (abs >= 1_000_000_000) {
      return `${sign}${symbol}${(abs / 1_000_000_000).toFixed(2)}B`;
    }
    if (abs >= 1_000_000) {
      return `${sign}${symbol}${(abs / 1_000_000).toFixed(2)}M`;
    }
    if (abs >= 1_000) {
      return `${sign}${symbol}${(abs / 1_000).toFixed(1)}k`;
    }
    return `${sign}${symbol}${abs.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
  }

  const isJPY = currency === 'JPY';
  const formatted = Math.abs(amount).toLocaleString('en-US', {
    minimumFractionDigits: isJPY ? 0 : 2,
    maximumFractionDigits: isJPY ? 0 : 2,
  });

  return `${amount < 0 ? '-' : ''}${symbol}${formatted}`;
}

/**
 * Converts any native currency amount to USD using current FX rates
 */
export function convertToUSD(amountNative: number, currency: Currency, fxRates: FXRate[]): number {
  if (currency === 'USD') return amountNative;
  if (currency === 'EUR') {
    const rate = fxRates.find(r => r.pair === 'EUR/USD')?.rate || 1.0845;
    return amountNative * rate;
  }
  if (currency === 'GBP') {
    const rate = fxRates.find(r => r.pair === 'GBP/USD')?.rate || 1.2980;
    return amountNative * rate;
  }
  if (currency === 'JPY') {
    const rate = fxRates.find(r => r.pair === 'USD/JPY')?.rate || 148.25;
    return amountNative / rate;
  }
  if (currency === 'SGD') {
    const rate = fxRates.find(r => r.pair === 'USD/SGD')?.rate || 1.3140;
    return amountNative / rate;
  }
  return amountNative;
}

/**
 * Converts USD amount to a chosen target currency
 */
export function convertFromUSD(amountUSD: number, targetCurrency: Currency, fxRates: FXRate[]): number {
  if (targetCurrency === 'USD') return amountUSD;
  if (targetCurrency === 'EUR') {
    const rate = fxRates.find(r => r.pair === 'EUR/USD')?.rate || 1.0845;
    return amountUSD / rate;
  }
  if (targetCurrency === 'GBP') {
    const rate = fxRates.find(r => r.pair === 'GBP/USD')?.rate || 1.2980;
    return amountUSD / rate;
  }
  if (targetCurrency === 'JPY') {
    const rate = fxRates.find(r => r.pair === 'USD/JPY')?.rate || 148.25;
    return amountUSD * rate;
  }
  if (targetCurrency === 'SGD') {
    const rate = fxRates.find(r => r.pair === 'USD/SGD')?.rate || 1.3140;
    return amountUSD * rate;
  }
  return amountUSD;
}

export function truncateHash(hash: string, start: number = 8, end: number = 6): string {
  if (!hash) return '';
  if (hash.length <= start + end) return hash;
  return `${hash.substring(0, start)}...${hash.substring(hash.length - end)}`;
}
