import { ForecastDay, ForecastScenario } from '../types/treasury';

export interface ForecastSummary {
  days: ForecastDay[];
  currentCashUSD: number;
  projected30dUSD: number;
  projected60dUSD: number;
  projected90dUSD: number;
  minBufferUSD: number;
  bufferBreachDay: number | null; // null if safe
  dcoh: number; // Days of Cash on Hand
  runwayMonths: number;
  totalInflow90d: number;
  totalOutflow90d: number;
  netVarianceUSD: number;
}

export function generateForecastData(
  initialCashUSD: number,
  horizonDays: number = 90,
  scenario: ForecastScenario = 'BASE_CASE'
): ForecastSummary {
  const days: ForecastDay[] = [];
  let runningCash = initialCashUSD;
  const minBuffer = 25000000; // $25M corporate policy buffer
  let bufferBreachDay: number | null = null;
  let totalInflow90d = 0;
  let totalOutflow90d = 0;

  // Multipliers based on scenario stress
  let arMultiplier = 1.0;
  let capexMultiplier = 1.0;
  let opexMultiplier = 1.0;

  if (scenario === 'CONSERVATIVE_AR_DELAY') {
    arMultiplier = 0.78; // 22% delay pushed past quarter
    opexMultiplier = 1.02;
  } else if (scenario === 'CAPEX_EXPANSION') {
    capexMultiplier = 2.4; // heavy equipment / tech infrastructure outlays
  } else if (scenario === 'MACRO_STRESS_TEST') {
    arMultiplier = 0.70; // 30% contraction
    opexMultiplier = 1.12; // inflation pressure
    capexMultiplier = 1.25;
  }

  const baseDate = new Date(2026, 8, 28); // Sep 28, 2026

  for (let i = 1; i <= horizonDays; i++) {
    const curDate = new Date(baseDate);
    curDate.setDate(curDate.getDate() + i);

    const isWeekend = curDate.getDay() === 0 || curDate.getDay() === 6;
    const isFriday = curDate.getDay() === 5;
    const isBiWeeklyPayroll = i % 14 === 4; // payroll every 2 weeks
    const isQuarterEndTax = i === 15 || i === 75;
    const isMonthEnd = curDate.getDate() >= 28 && curDate.getDate() <= 31;

    // Daily Inflows
    let arCollections = isWeekend ? 0 : (850000 + Math.sin(i * 0.4) * 320000) * arMultiplier;
    let subscriptionBilling = isMonthEnd ? 4200000 * arMultiplier : (isWeekend ? 40000 : 380000);
    let treasuryYield = (runningCash * 0.051) / 365; // ~5.1% blended yield on cash
    let otherInflows = isFriday ? 220000 : 45000;

    // Daily Outflows
    let accountsPayable = isWeekend ? 0 : (640000 + Math.cos(i * 0.3) * 190000) * opexMultiplier;
    let payrollRun = isBiWeeklyPayroll ? 4850000 * opexMultiplier : 0;
    let capexExpenses = (i % 10 === 0 ? 1400000 : (i === 45 ? 5800000 : 0)) * capexMultiplier;
    let taxAndInterest = isQuarterEndTax ? 3200000 : (i % 30 === 0 ? 950000 : 0);

    const totalIn = Math.round(arCollections + subscriptionBilling + treasuryYield + otherInflows);
    const totalOut = Math.round(accountsPayable + payrollRun + capexExpenses + taxAndInterest);
    const net = totalIn - totalOut;

    runningCash += net;
    totalInflow90d += totalIn;
    totalOutflow90d += totalOut;

    if (runningCash < minBuffer && bufferBreachDay === null) {
      bufferBreachDay = i;
    }

    const dateStr = curDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

    days.push({
      dayIndex: i,
      dateStr,
      inflows: {
        arCollections: Math.round(arCollections),
        subscriptionBilling: Math.round(subscriptionBilling),
        treasuryYield: Math.round(treasuryYield),
        otherInflows: Math.round(otherInflows),
      },
      outflows: {
        accountsPayable: Math.round(accountsPayable),
        payrollRun: Math.round(payrollRun),
        capexExpenses: Math.round(capexExpenses),
        taxAndInterest: Math.round(taxAndInterest),
      },
      totalInflow: totalIn,
      totalOutflow: totalOut,
      netCashFlow: net,
      closingCash: Math.round(runningCash),
    });
  }

  const projected30d = days[29]?.closingCash ?? runningCash;
  const projected60d = days[59]?.closingCash ?? runningCash;
  const projected90d = days[89]?.closingCash ?? runningCash;

  // Average daily net outflow (burn) if negative, or daily operating cost
  const avgDailyOutflow = totalOutflow90d / horizonDays;
  const dcoh = Math.round(initialCashUSD / (avgDailyOutflow || 1));
  const runwayMonths = Number((initialCashUSD / ((totalOutflow90d - totalInflow90d > 0 ? (totalOutflow90d - totalInflow90d) / 3 : avgDailyOutflow * 30))).toFixed(1));

  return {
    days,
    currentCashUSD: initialCashUSD,
    projected30dUSD: projected30d,
    projected60dUSD: projected60d,
    projected90dUSD: projected90d,
    minBufferUSD: minBuffer,
    bufferBreachDay,
    dcoh,
    runwayMonths: isFinite(runwayMonths) && runwayMonths > 0 ? runwayMonths : 36.0,
    totalInflow90d,
    totalOutflow90d,
    netVarianceUSD: runningCash - initialCashUSD,
  };
}
