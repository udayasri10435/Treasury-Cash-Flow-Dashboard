/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Currency,
  BankAccount,
  LegalEntity,
  IntercompanySweepRule,
  FXRate,
  FXExposureHolding,
  FXHedgeContract,
  LedgerBlock,
  BankConnectorStatus,
  UserPersona,
} from './types/treasury';
import {
  USER_PERSONAS,
  LEGAL_ENTITIES,
  INITIAL_BANK_ACCOUNTS,
  INITIAL_SWEEP_RULES,
  INITIAL_FX_RATES,
  INITIAL_FX_EXPOSURES,
  INITIAL_FX_HEDGES,
  INITIAL_LEDGER_CHAIN,
  INITIAL_BANK_CONNECTORS,
} from './data/initialTreasuryData';
import { TopNav, ActiveTab } from './components/TopNav';
import { CashPositionView } from './components/CashPositionView';
import { CashForecastView } from './components/CashForecastView';
import { FXExposureView } from './components/FXExposureView';
import { ImmutableLedgerView } from './components/ImmutableLedgerView';
import { BankConnectorsView } from './components/BankConnectorsView';
import { InitiateSweepModal } from './components/Modals/InitiateSweepModal';
import { ExecuteHedgeModal } from './components/Modals/ExecuteHedgeModal';
import { PlaidLinkModal } from './components/Modals/PlaidLinkModal';
import { SwiftParserModal } from './components/Modals/SwiftParserModal';
import { AuditExportModal } from './components/Modals/AuditExportModal';
import { sealBlock } from './utils/cryptoLedger';
import { convertToUSD } from './utils/formatters';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('CASH_POSITION');
  const [baseCurrency, setBaseCurrency] = useState<Currency>('USD');
  const [activeUser, setActiveUser] = useState<UserPersona>(USER_PERSONAS[0]);

  // Master State
  const [accounts, setAccounts] = useState<BankAccount[]>(INITIAL_BANK_ACCOUNTS);
  const [entities] = useState<LegalEntity[]>(LEGAL_ENTITIES);
  const [sweepRules, setSweepRules] = useState<IntercompanySweepRule[]>(INITIAL_SWEEP_RULES);
  const [fxRates, setFxRates] = useState<FXRate[]>(INITIAL_FX_RATES);
  const [fxExposures, setFxExposures] = useState<FXExposureHolding[]>(INITIAL_FX_EXPOSURES);
  const [fxHedges, setFxHedges] = useState<FXHedgeContract[]>(INITIAL_FX_HEDGES);
  const [ledgerChain, setLedgerChain] = useState<LedgerBlock[]>(INITIAL_LEDGER_CHAIN);
  const [bankConnectors, setBankConnectors] = useState<BankConnectorStatus[]>(INITIAL_BANK_CONNECTORS);

  // Modals state
  const [isSweepModalOpen, setIsSweepModalOpen] = useState(false);
  const [isHedgeModalOpen, setIsHedgeModalOpen] = useState(false);
  const [isPlaidModalOpen, setIsPlaidModalOpen] = useState(false);
  const [isSwiftModalOpen, setIsSwiftModalOpen] = useState(false);
  const [isAuditModalOpen, setIsAuditModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3800);
  };

  // Append new block to cryptographic chain
  const appendLedgerBlock = async (
    eventType: LedgerBlock['eventType'],
    entityCode: string,
    description: string,
    amountUSD: number,
    approver?: string
  ) => {
    const prevBlock = ledgerChain[ledgerChain.length - 1];
    const prevHash = prevBlock ? prevBlock.hash : '0000000000000000000000000000000000000000000000000000000000000000';
    const nextIndex = ledgerChain.length;

    const unsealedBlockData = {
      blockIndex: nextIndex,
      timestamp: new Date().toISOString(),
      eventType,
      entityCode,
      description,
      amountUSD,
      actor: activeUser.name,
      actorRole: activeUser.role,
      approver: approver || (amountUSD >= 500000 ? 'Eleanor Vance, CFA (Dual-Auth #9410)' : undefined),
      prevHash,
      nonce: Math.floor(10000 + Math.random() * 89999),
      merkleRoot: Math.random().toString(16).substring(2, 34),
    };

    const sealed = await sealBlock(unsealedBlockData);
    setLedgerChain((prev) => [...prev, sealed]);
  };

  // Sweep Handler
  const handleConfirmSweep = async (sweepData: {
    sourceAccountId: string;
    targetAccountId: string;
    amountNative: number;
    currency: Currency;
    memo: string;
  }) => {
    const src = accounts.find((a) => a.id === sweepData.sourceAccountId);
    const tgt = accounts.find((a) => a.id === sweepData.targetAccountId);
    if (!src || !tgt) return;

    // Deduct from source and add to target
    setAccounts((prev) =>
      prev.map((acc) => {
        if (acc.id === sweepData.sourceAccountId) {
          return { ...acc, balanceNative: Math.max(0, acc.balanceNative - sweepData.amountNative), lastSyncTimestamp: 'Just now' };
        }
        if (acc.id === sweepData.targetAccountId) {
          // If different currencies, convert to target currency
          const amountUSD = convertToUSD(sweepData.amountNative, sweepData.currency, fxRates);
          const convertedAmt = sweepData.currency === acc.currency ? sweepData.amountNative : (amountUSD * 1.0);
          return { ...acc, balanceNative: acc.balanceNative + convertedAmt, lastSyncTimestamp: 'Just now' };
        }
        return acc;
      })
    );

    const amountUSD = convertToUSD(sweepData.amountNative, sweepData.currency, fxRates);
    const entityCode = entities.find((e) => e.id === src.entityId)?.code || 'APEX-GLOBAL';

    await appendLedgerBlock(
      'SWEEP_EXECUTION',
      entityCode,
      `Physical intercompany cash sweep of ${sweepData.currency} ${sweepData.amountNative.toLocaleString()} from ${src.bankName} to ${tgt.bankName}. Memo: ${sweepData.memo}`,
      amountUSD
    );

    showToast(`Sweep of ${sweepData.currency} ${sweepData.amountNative.toLocaleString()} executed & sealed into Block #${ledgerChain.length}`);
  };

  // Automated ZBA Balancing Trigger
  const handleExecuteAutoBalancing = async () => {
    const sweepAmtUSD = 3500000;
    setAccounts((prev) =>
      prev.map((acc) => {
        if (acc.id === 'acc_bnp_eur') {
          return { ...acc, balanceNative: 15000000, lastSyncTimestamp: 'Just now' };
        }
        if (acc.id === 'acc_jpm_op') {
          return { ...acc, balanceNative: acc.balanceNative + 3225000, lastSyncTimestamp: 'Just now' };
        }
        return acc;
      })
    );

    await appendLedgerBlock(
      'SWEEP_EXECUTION',
      'APEX-NL',
      'Zero-Balance Account (ZBA) automated target balancing sweep executed for Continental Europe pool to US Parent',
      sweepAmtUSD,
      'Automated Treasury Robot Rule #01'
    );

    showToast('Automated ZBA balancing executed. Excess cash swept to Master Operating account.');
  };

  // FX Hedge Execution Handler
  const handleConfirmHedge = async (hedgeData: {
    pair: string;
    instrument: 'FORWARD' | 'SWAP' | 'COLLAR_OPTION';
    notionalNative: number;
    nativeCurrency: Currency;
    counterCurrency: Currency;
    lockedRate: number;
    settlementDate: string;
    counterpartyBank: string;
  }) => {
    const newContract: FXHedgeContract = {
      id: `hdg_${Date.now()}`,
      contractRef: `FWD-2026-${hedgeData.nativeCurrency}-${Math.floor(100 + Math.random() * 900)}`,
      instrument: hedgeData.instrument,
      pair: hedgeData.pair,
      notionalNative: hedgeData.notionalNative,
      nativeCurrency: hedgeData.nativeCurrency,
      counterCurrency: hedgeData.counterCurrency,
      lockedRate: hedgeData.lockedRate,
      currentRate: hedgeData.lockedRate,
      markToMarketUSD: 0,
      settlementDate: hedgeData.settlementDate,
      counterpartyBank: hedgeData.counterpartyBank,
      status: 'ACTIVE',
    };

    setFxHedges((prev) => [newContract, ...prev]);

    // Update hedge ratio in exposures
    setFxExposures((prev) =>
      prev.map((exp) => {
        if (exp.currency === hedgeData.nativeCurrency) {
          const addedUSD = convertToUSD(hedgeData.notionalNative, hedgeData.nativeCurrency, fxRates);
          const newHedged = exp.hedgedAmountUSD + addedUSD;
          const newUnhedged = exp.netPositionUSD - newHedged;
          const newRatio = (newHedged / exp.netPositionUSD) * 100;
          return {
            ...exp,
            hedgedAmountUSD: newHedged,
            unhedgedExposureUSD: newUnhedged,
            hedgeRatioPercent: Math.min(newRatio, 100),
          };
        }
        return exp;
      })
    );

    const amountUSD = convertToUSD(hedgeData.notionalNative, hedgeData.nativeCurrency, fxRates);

    await appendLedgerBlock(
      'FX_HEDGE_SETTLEMENT',
      'APEX-US',
      `Executed ${hedgeData.instrument} on ${hedgeData.pair} (Notional: ${hedgeData.nativeCurrency} ${hedgeData.notionalNative.toLocaleString()} @ ${hedgeData.lockedRate.toFixed(4)}) with ${hedgeData.counterpartyBank}`,
      amountUSD
    );

    showToast(`FX Hedge ${newContract.contractRef} executed and sealed into Immutable Ledger.`);
  };

  // Plaid Link account linked
  const handleAccountLinked = async (newAcc: BankAccount) => {
    setAccounts((prev) => [newAcc, ...prev]);

    // Update connector account count
    setBankConnectors((prev) =>
      prev.map((conn) =>
        conn.provider === 'PLAID' ? { ...conn, activeAccounts: conn.activeAccounts + 1, lastPolled: 'Just now' } : conn
      )
    );

    const amtUSD = convertToUSD(newAcc.balanceNative, newAcc.currency, fxRates);
    await appendLedgerBlock(
      'BANK_FEED_RECONCILED',
      'APEX-US',
      `Direct Plaid Core API integration authenticated for ${newAcc.bankName} (${newAcc.accountName})`,
      amtUSD
    );

    showToast(`${newAcc.bankName} account successfully linked via Plaid.`);
  };

  // SWIFT MT940 statement reconciled
  const handleReconciliationComplete = async (accountId: string, newBalance: number, memo: string) => {
    const acc = accounts.find((a) => a.id === accountId);
    if (!acc) return;

    setAccounts((prev) =>
      prev.map((a) => (a.id === accountId ? { ...a, balanceNative: newBalance, lastSyncTimestamp: 'Just now', status: 'RECONCILED' } : a))
    );

    const amtUSD = convertToUSD(newBalance, acc.currency, fxRates);
    await appendLedgerBlock(
      'BANK_FEED_RECONCILED',
      'APEX-NL',
      `SWIFT Alliance MT940 statement ingestion & closing balance reconciliation for ${acc.bankName}: ${memo}`,
      amtUSD
    );

    showToast(`SWIFT MT940 reconciliation applied to ${acc.bankName}.`);
  };

  // Simulate market rate shock
  const handleSimulateRateShock = () => {
    setFxRates((prev) =>
      prev.map((r) => {
        const delta = (Math.random() - 0.48) * 0.012;
        const newRate = Number((r.rate * (1 + delta)).toFixed(4));
        return {
          ...r,
          rate: newRate,
          change24h: Number((r.change24h + delta * 100).toFixed(2)),
          lastUpdated: 'Simulated shock just now',
        };
      })
    );

    // Re-mark hedges to market
    setFxHedges((prev) =>
      prev.map((hdg) => {
        const pnlDelta = (Math.random() - 0.49) * 18000;
        return {
          ...hdg,
          markToMarketUSD: Math.round(hdg.markToMarketUSD + pnlDelta),
        };
      })
    );

    showToast('Market rate shock simulated. Spot rates and forward points updated.');
  };

  // Tamper simulation for cryptographic demonstration
  const handleTamperBlock = (blockIndex: number) => {
    setLedgerChain((prev) =>
      prev.map((b) => {
        if (b.blockIndex === blockIndex) {
          return {
            ...b,
            amountUSD: 99999999, // Fraudulent alteration
            description: '[TAMPERED] Unauthorized fund transfer divert to offshore shell account',
            isTampered: true,
          };
        }
        return b;
      })
    );
    showToast(`Block #${blockIndex} maliciously mutated. Click "Verify Ledger Integrity" to test tamper detection.`);
  };

  const handleRestoreChain = () => {
    setLedgerChain(INITIAL_LEDGER_CHAIN);
    showToast('Authentic cryptographic ledger restored.');
  };

  const handlePollAllFeeds = () => {
    setBankConnectors((prev) =>
      prev.map((c) => ({
        ...c,
        lastPolled: 'Just now',
        latencyMs: Math.floor(40 + Math.random() * 90),
      }))
    );
    setAccounts((prev) =>
      prev.map((a) => ({
        ...a,
        lastSyncTimestamp: 'Just now',
      }))
    );
    showToast('All Plaid, Yodlee, and SWIFT bank feeds successfully polled.');
  };

  const totalCashUSD = accounts
    .filter((a) => a.liquidityTier !== 'TIER_4_CREDIT_FACILITY')
    .reduce((sum, a) => sum + convertToUSD(a.balanceNative, a.currency, fxRates), 0);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Universal Top Navigation */}
      <TopNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        baseCurrency={baseCurrency}
        setBaseCurrency={setBaseCurrency}
        activeUser={activeUser}
        setActiveUser={setActiveUser}
        onOpenAuditExport={() => setIsAuditModalOpen(true)}
      />

      {/* Main Viewport Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6">
        {activeTab === 'CASH_POSITION' && (
          <CashPositionView
            accounts={accounts}
            entities={entities}
            sweepRules={sweepRules}
            fxRates={fxRates}
            baseCurrency={baseCurrency}
            activeUser={activeUser}
            onOpenSweepModal={() => setIsSweepModalOpen(true)}
            onExecuteAutoBalancing={handleExecuteAutoBalancing}
            onRefreshFeed={handlePollAllFeeds}
          />
        )}

        {activeTab === 'FORECASTING' && (
          <CashForecastView
            initialCashUSD={totalCashUSD}
            baseCurrency={baseCurrency}
            activeUser={activeUser}
          />
        )}

        {activeTab === 'FX_EXPOSURE' && (
          <FXExposureView
            fxExposures={fxExposures}
            fxHedges={fxHedges}
            fxRates={fxRates}
            baseCurrency={baseCurrency}
            activeUser={activeUser}
            onOpenHedgeModal={() => setIsHedgeModalOpen(true)}
            onSimulateRateShock={handleSimulateRateShock}
          />
        )}

        {activeTab === 'IMMUTABLE_LEDGER' && (
          <ImmutableLedgerView
            chain={ledgerChain}
            activeUser={activeUser}
            onOpenAuditExport={() => setIsAuditModalOpen(true)}
            onTamperBlock={handleTamperBlock}
            onRestoreChain={handleRestoreChain}
          />
        )}

        {activeTab === 'BANK_CONNECTORS' && (
          <BankConnectorsView
            connectors={bankConnectors}
            accounts={accounts}
            activeUser={activeUser}
            onOpenPlaidLink={() => setIsPlaidModalOpen(true)}
            onOpenSwiftParser={() => setIsSwiftModalOpen(true)}
            onPollAllFeeds={handlePollAllFeeds}
          />
        )}
      </main>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 border border-cyan-500/50 text-slate-100 text-xs px-4 py-3 rounded-xl shadow-2xl flex items-center gap-3 backdrop-blur-md animate-in fade-in slide-in-from-bottom-2">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Modals */}
      <InitiateSweepModal
        isOpen={isSweepModalOpen}
        onClose={() => setIsSweepModalOpen(false)}
        accounts={accounts}
        activeUser={activeUser}
        onConfirmSweep={handleConfirmSweep}
      />

      <ExecuteHedgeModal
        isOpen={isHedgeModalOpen}
        onClose={() => setIsHedgeModalOpen(false)}
        fxRates={fxRates}
        activeUser={activeUser}
        onConfirmHedge={handleConfirmHedge}
      />

      <PlaidLinkModal
        isOpen={isPlaidModalOpen}
        onClose={() => setIsPlaidModalOpen(false)}
        entities={entities}
        onAccountLinked={handleAccountLinked}
      />

      <SwiftParserModal
        isOpen={isSwiftModalOpen}
        onClose={() => setIsSwiftModalOpen(false)}
        accounts={accounts}
        onReconciliationComplete={handleReconciliationComplete}
      />

      <AuditExportModal
        isOpen={isAuditModalOpen}
        onClose={() => setIsAuditModalOpen(false)}
        chain={ledgerChain}
        activeUser={activeUser}
        isValidChain={!ledgerChain.some((b) => b.isTampered)}
      />
    </div>
  );
}
