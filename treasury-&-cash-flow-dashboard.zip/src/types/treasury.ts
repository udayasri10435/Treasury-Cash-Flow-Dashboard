export type Currency = 'USD' | 'EUR' | 'GBP' | 'JPY' | 'SGD';

export type UserRole = 
  | 'CHIEF_TREASURER'      // Full approval rights (> $500k disbursements, hedges, overrides)
  | 'CASH_MANAGER'         // Operational rights (daily liquidity, sweeps, target balancing)
  | 'TREASURY_ANALYST'     // Analytical rights (forecasting, stress-tests, variance, reports)
  | 'COMPLIANCE_AUDITOR';  // Read-only audit rights (ledger cryptographic verification, SOX reports)

export interface UserPersona {
  id: string;
  name: string;
  role: UserRole;
  roleTitle: string;
  department: string;
  avatarInitials: string;
  colorScheme: string;
  permissions: {
    canApproveHighValueTransfers: boolean;
    canExecuteFXHedges: boolean;
    canInitiateSweeps: boolean;
    canModifyForecastScenarios: boolean;
    canVerifyAuditLedger: boolean;
    canConnectBankAPIs: boolean;
  };
}

export interface LegalEntity {
  id: string;
  name: string;
  code: string;
  jurisdiction: string;
  baseCurrency: Currency;
  taxId: string;
}

export type LiquidityTier = 'TIER_1_CASH' | 'TIER_2_SWEEP_MMF' | 'TIER_3_TERM_DEPOSIT' | 'TIER_4_CREDIT_FACILITY';

export interface BankAccount {
  id: string;
  entityId: string;
  bankName: string;
  bankCode: 'JPM' | 'CITI' | 'HSBC' | 'BNP' | 'BARCLAYS' | 'DEUTSCHE';
  accountName: string;
  accountNumberMask: string;
  iban: string;
  currency: Currency;
  balanceNative: number;
  liquidityTier: LiquidityTier;
  interestRateAPY: number;
  lastSyncTimestamp: string;
  apiProvider: 'PLAID' | 'YODLEE' | 'SWIFT_HOST_TO_HOST';
  status: 'ONLINE' | 'SYNCING' | 'RECONCILED' | 'REQUIRES_REAUTH';
}

export interface IntercompanySweepRule {
  id: string;
  sourceAccountId: string;
  targetAccountId: string;
  sourceEntityId: string;
  targetEntityId: string;
  ruleType: 'ZERO_BALANCE' | 'TARGET_BALANCE' | 'EXCESS_SWEEP';
  targetThresholdNative: number;
  currency: Currency;
  executionFrequency: 'DAILY_END_OF_DAY' | 'REAL_TIME' | 'MANUAL';
  lastExecuted?: string;
  isActive: boolean;
}

export interface ForecastDay {
  dayIndex: number;
  dateStr: string;
  inflows: {
    arCollections: number;
    subscriptionBilling: number;
    treasuryYield: number;
    otherInflows: number;
  };
  outflows: {
    accountsPayable: number;
    payrollRun: number;
    capexExpenses: number;
    taxAndInterest: number;
  };
  totalInflow: number;
  totalOutflow: number;
  netCashFlow: number;
  closingCash: number;
}

export type ForecastScenario = 
  | 'BASE_CASE'
  | 'CONSERVATIVE_AR_DELAY'
  | 'CAPEX_EXPANSION'
  | 'MACRO_STRESS_TEST';

export interface FXRate {
  pair: string; // e.g. 'EUR/USD'
  base: Currency;
  quote: Currency;
  rate: number;
  change24h: number; // percentage
  forward30d: number;
  forward90d: number;
  lastUpdated: string;
}

export interface FXExposureHolding {
  currency: Currency;
  grossAssetsUSD: number;
  grossLiabilitiesUSD: number;
  netPositionUSD: number;
  hedgedAmountUSD: number;
  unhedgedExposureUSD: number;
  hedgeRatioPercent: number;
  targetHedgeRatio: number;
}

export interface FXHedgeContract {
  id: string;
  contractRef: string;
  instrument: 'FORWARD' | 'SWAP' | 'COLLAR_OPTION';
  pair: string;
  notionalNative: number;
  nativeCurrency: Currency;
  counterCurrency: Currency;
  lockedRate: number;
  currentRate: number;
  markToMarketUSD: number;
  settlementDate: string;
  counterpartyBank: string;
  status: 'ACTIVE' | 'SETTLING' | 'MATURED';
}

export interface LedgerBlock {
  blockIndex: number;
  timestamp: string;
  eventType: 
    | 'GENESIS_BLOCK'
    | 'SWEEP_EXECUTION'
    | 'FX_HEDGE_SETTLEMENT'
    | 'HIGH_VALUE_DISBURSEMENT'
    | 'BANK_FEED_RECONCILED'
    | 'POLICY_CHANGE'
    | 'API_TOKEN_ROTATION';
  entityCode: string;
  description: string;
  amountUSD: number;
  actor: string;
  actorRole: UserRole;
  approver?: string;
  prevHash: string;
  hash: string;
  nonce: number;
  merkleRoot: string;
  isTampered?: boolean;
}

export interface BankConnectorStatus {
  id: string;
  name: string;
  provider: 'PLAID' | 'YODLEE' | 'SWIFT';
  institutionsConnected: number;
  activeAccounts: number;
  lastPolled: string;
  latencyMs: number;
  webhookStatus: 'HEALTHY' | 'DEGRADED' | 'DISCONNECTED';
  protocol: string;
}
